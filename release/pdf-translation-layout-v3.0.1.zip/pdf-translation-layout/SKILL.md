---
name: pdf-translation-layout
description: |
  Hệ sinh thái Dịch thuật, Dàn trang Vector Thích ứng và Xuất bản Đa phương tiện Song ngữ v3.0 (Universal Vector PDF & Media Publishing Ecosystem) theo triết lý "Zero-Rasterization & Micro-Typographic Fitting".
  Bảo tồn 100% Vector Text Layers (selectable, searchable), kích thước trang, lưới bố cục, màu sắc nhận diện, bảng biểu, hyperlinks nội bộ/ngoài và hình ảnh minh họa gốc.
  Hỗ trợ 3 Chế độ Xuất bản Toàn diện:
    1. Mono-Target: Dàn trang tiếng Việt đơn ngữ bảo tồn 100% bố cục vector gốc.
    2. Dual Bilingual Layouts: Bố cục Đối trang 1-1 (Facing Book / Sheet) & Bố cục Xen đoạn (Interleaved Flow với màu nhận diện #0a7a8c).
    3. Multimedia Studio: Phòng thu giọng đọc AI VieNeu-TTS v3 (Đức Trí, Minh Quân, Andrew, Adam) kèm Nhân bản Giọng nói 3-8s và Engine xuất bản Video Đọc Sách 1080p Broadcast Standard (25fps constant framerate, 48kHz AAC, đồng bộ bounding box highlight).
  Tích hợp Cổng kiểm định tự động 4 tầng (Mechanical, Geometric, Content/Tofu, Visual QA).
  Kích hoạt khi người dùng yêu cầu: "dịch pdf giữ layout", "dàn trang pdf", "translate pdf preserve formatting", "dịch sách song ngữ", "bilingual pdf", "xuất video đọc sách", "lồng tiếng pdf", "pdf-translation-layout", hoặc cần xuất bản ấn phẩm PDF/Video chất lượng cao từ tài liệu PDF gốc.
version: 3.0.1
status: approved
zone: B
keywords: [pdf, translation, layout, adaptive-typography, vector-pdf, pymupdf, zero-rasterization, bilingual, facing-pages, interleaved, vieneu-tts, voice-cloning, reading-video, broadcast-video, qa-verification]
---

# Hệ Sinh Thái Dịch Thuật & Dàn Trang PDF Vector Thích Ứng Chuẩn Xuất Bản
## (Universal Vector PDF & Media Publishing Ecosystem v3.0)

---

## 1. Triết Lý Kỹ Sư Cốt Lõi (Core Principles)

Hệ thống được phát triển theo triết lý kỹ sư thực chứng (**Skills for Real Engineers — Anti-Vibe Coding**), loại bỏ triệt để các cách làm "cưỡng ép" thô sơ (như rasterize/ảnh hóa trang làm mờ chữ, mất khả năng tìm kiếm văn bản, hay thu nhỏ cỡ chữ vô tội vạ làm phá vỡ phân cấp thị giác):

1. **Tuyệt đối không ảnh hóa văn bản (Zero-Rasterization Rule)**:
   - 100% các trang tài liệu đều duy trì **Vector Text Layer thật**.
   - Văn bản xuất bản cho phép bôi đen, sao chép (`Ctrl+C`), tìm kiếm ngữ nghĩa (`Ctrl+F`), tương thích máy in ấn DPI cao và trình đọc màn hình cho người khiếm thị (Screen Readers).
2. **Bất biến tài liệu nguồn (Source PDF Immutability)**:
   - Tệp PDF nguồn luôn được mở ở chế độ chỉ đọc (**Read-only**). Mọi bản dịch và phái sinh đều xuất ra tệp mới theo phiên bản rõ ràng.
3. **Thích ứng Typography Vi mô (Micro-Typographic Adaptive Fitting)**:
   - Xử lý triệt để độ nở tự nhiên của tiếng Việt (**12% – 18%**) bằng thứ tự ưu tiên: Nới rộng bề ngang dòng (`x1_max +18 pt`) $\rightarrow$ Tinh chỉnh khoảng cách dòng (`leading`) $\rightarrow$ Thu gọn khoảng trống đoạn (`space_after`) $\rightarrow$ Co tỷ lệ typography theo thang đo `sc ∈ [1.0 .. 0.67]`.
4. **Hệ Sinh Thái Xuất Bản Đa Chiều (Multi-Dimensional Publishing)**:
   - Không chỉ xuất bản tệp PDF dịch đơn ngữ, hệ thống cho phép xuất bản **2 Bố cục Song ngữ** (Đối trang & Xen đoạn) cùng **Video Đọc Sách 1080p Broadcast** với giọng đọc AI tự nhiên VieNeu-TTS.
5. **Chuẩn Âm Thanh & Video Phát Sóng (Broadcast Standard 25fps + 48kHz AAC)**:
   - Video đọc sách áp dụng kiến trúc Single-Pass: Cố định 25.000 fps, Audio 48,000 Hz AAC, đồng bộ bounding box và phụ đề từng câu, triệt tiêu 100% hiện tượng "éo tiếng / méo tiếng".

---

## 2. Ba Chế Độ Xuất Bản Toàn Diện

```mermaid
graph TD
    SourcePDF["📄 PDF Nguồn Tiếng Anh (Gốc)"] --> CLI["🚀 Unified CLI (scripts/cli.py)"]
    
    CLI --> Mode1["Chế độ 1: Mono-Target\n(Bản Dịch Tiếng Việt Vector 100%)"]
    CLI --> Mode2["Chế độ 2: Dual Bilingual Layouts\n(2 Bố Cục Song Ngữ Xuất Bản)"]
    CLI --> Mode3["Chế độ 3: Multimedia Publishing\n(Voice Studio & Video 1080p)"]
    
    Mode1 --> OutMono["📁 output/*-VI-Full-Pages-v1.pdf\n(Bảo tồn 100% layout, 0 tofu, font CID)"]
    
    Mode2 --> LayoutA["📖 Layout A: Đối Trang (Facing)\n- facing_book.pdf (Trái EN | Phải VI)\n- facing_sheet.pdf (Khổ đôi 2-up)"]
    Mode2 --> LayoutB["📝 Layout B: Xen Đoạn (Interleaved)\n- interleaved.pdf (Tô màu nhận diện #0a7a8c)"]
    
    Mode3 --> Audio["🎙️ Voice Studio (VieNeu-TTS v3)\n- Đóng gói sẵn: Đức Trí, Minh Quân, Andrew\n- Clone giọng từ mẫu 3-8 giây"]
    Mode3 --> Video["🎬 Reading Video 1080p (MP4)\n- 25 fps constant, 48kHz AAC\n- Highlight bounding box & phụ đề 2 dòng"]
```

---

## 3. Quy Trình Vận Hành Tiêu Chuẩn 6 Bước (End-to-End Workflow)

### Bước 1: Kiểm Kê Cơ Khí & Trích Xuất Dữ Liệu Nguồn (`inspect`)
Quét toàn bộ cấu trúc PDF nguồn: số trang, kích thước, ma trận Skia `Tm`, bảng mã font, danh sách hình ảnh, bảng biểu và siêu liên kết.
```bash
python scripts/cli.py inspect --source input/book.pdf --out-dir data/
```
*Đầu ra*: `data/full_book_raw.json`.

### Bước 2: Dịch Thuật Chuẩn Hóa & Quản Trị Thuật Ngữ
Xây dựng bảng thuật ngữ `docs/glossary.md` và tiến hành dịch thuật có cấu trúc (bảo tồn 1-1 style, chữ in hoa, in nghiêng, superscript và đích liên kết).
*Đầu ra*: `data/full_book_translations.json`.

### Bước 3: Việt Hóa Đồ Họa & Biểu Đồ (`figure_localizer.py`)
Tự động lấy mẫu màu nền xung quanh nhãn tiếng Anh, xóa nhãn cũ và ghi nhãn tiếng Việt bằng font `Plus Jakarta Sans`, hỗ trợ xoay tọa độ 90°.
```bash
python scripts/figure_localizer.py --image assets/figures/chart.png --config chart_labels.json
```

### Bước 4: Dàn Trang Vector Thích Ứng (`translate-mono` hoặc `bilingual`)
- **Xuất bản đơn ngữ (Mono-Target)**:
  ```bash
  python scripts/cli.py translate-mono --source input/book.pdf --trans data/full_book_translations.json --out output/book_VI_v1.pdf
  ```
- **Xuất bản song ngữ (Bilingual Layouts)**:
  ```bash
  # Xuất cả Đối trang (Book & Sheet) và Xen đoạn:
  python scripts/cli.py bilingual --source input/book.pdf --trans output/book_VI_v1.pdf --mode all
  ```

### Bước 5: Tạo Giọng Đọc Phòng Thu AI VieNeu-TTS (`voice`)
- Tổng hợp giọng đọc mẫu:
  ```bash
  python scripts/cli.py voice synth --lang vi --voice "Đức Trí" --text "Chào mừng bạn đến với cẩm nang." --out hello_vi.wav
  ```
- Nhân bản giọng nói tức thì (Instant Voice Cloning) từ mẫu 3–8 giây:
  ```bash
  python scripts/cli.py voice clone --name "MyVoice" --lang vi --ref sample.wav --ref-text "Nội dung câu mẫu trong file ghi âm"
  ```
- Tạo toàn bộ audio cho từng phân đoạn theo manifest:
  ```bash
  python scripts/cli.py voice synth-segments --segments data/segments_vi.json --lang vi --voice "Đức Trí" --out-dir output/audio/vi
  ```

### Bước 6: Xuất Bản Video Đọc Sách 1080p Broadcast Standard (`video`)
- **Video Đọc Tiếng Việt**:
  ```bash
  python scripts/cli.py video --source input/book.pdf --trans output/book_VI_v1.pdf --manifest data/manifest.json --mode mono_vi --out output/video_tieng_viet.mp4
  ```
- **Video Đọc Song Ngữ Đan Xen (EN Andrew ➔ VI Đức Trí)**:
  ```bash
  python scripts/cli.py video --source input/book.pdf --trans output/book_VI_v1.pdf --manifest data/manifest.json --mode bilingual --out output/video_song_ngu.mp4
  ```

---

## 4. Cổng Kiểm Định Chất Lượng QA 4 Tầng Tự Động (`qa`)

Mọi ấn phẩm xuất bản phải vượt qua Cổng kiểm định độc lập `scripts/qa_verifier.py`:
```bash
python scripts/cli.py qa --source input/book.pdf --target output/book_VI_v1.pdf --report output/qa_report.json
```

| Tầng kiểm định | Tiêu chí kỹ thuật | Ngưỡng bắt buộc |
|---|---|---|
| **Tầng 1: Cơ khí (Mechanical)** | Số trang, kích thước chuẩn ($612 \times 792 \text{ pt}$), nhúng font CID | 100% Trùng khớp |
| **Tầng 2: Hình học (Geometric)** | Không tràn lề, không đè lên hình ảnh, không tràn ô bảng biểu | **`0` Vi phạm tuyệt đối** |
| **Tầng 3: Text Layer (Content)** | Không có ký tự rác / tofu (`\ufffd`, `□`), bảo tồn 100% hyperlinks | **`0` Ký tự Tofu** |
| **Tầng 4: Trực quan (Visual)** | Render đối chiếu 130 DPI so sánh song song với bản gốc | Đạt chuẩn xuất bản |

---

## 5. Danh Mục Công Cụ (`scripts/`) & Tài Liệu Tham Chiếu (`references/`)

- `scripts/cli.py`: Điểm gọi lệnh thống nhất đa nền tảng.
- `scripts/adaptive_pdf_engine.py`: Engine dàn trang vector thích ứng đơn ngữ.
- `scripts/bilingual_layouts.py`: Engine dàn trang Đối trang & Xen đoạn.
- `scripts/voice_studio.py`: Phòng thu âm thanh VieNeu-TTS v3 & Voice Cloning.
- `scripts/reading_video_engine.py`: Engine dựng video đọc sách 1080p 25fps + 48kHz AAC.
- `scripts/qa_verifier.py`: Bộ kiểm định tự động 4 tầng.
- `references/adaptive-typography-spec.md`: Đặc tả chi tiết thuật toán co giãn và phân vùng Zones.
- `references/bilingual-layout-spec.md`: Đặc tả 2 bố cục song ngữ chuẩn xuất bản.
- `references/voice-and-video-spec.md`: Đặc tả kiến trúc VieNeu-TTS và video broadcast.
- `references/production-runbook.md`: Cẩm nang vận hành sản xuất thực chiến.
- `references/qa-checklist-matrix.md`: Ma trận nghiệm thu chất lượng.
