# Đặc Tả Kiến Trúc Bố Cục Song Ngữ (Bilingual Layouts Specification v3.0)

Tài liệu này định nghĩa chi tiết 2 bố cục xuất bản song ngữ chuyên nghiệp trong hệ sinh thái `pdf-translation-layout` v3.0, bảo tồn 100% Vector Text Layer (Zero-Rasterization).

---

## 1. Triết Lý Thiết Kế Song Ngữ (Core Principles)

1. **Bảo tồn 100% Vector Text Layer**:
   - Cả văn bản tiếng Anh gốc và văn bản tiếng Việt dịch đều là các đối tượng Vector Text thật sự, cho phép độc giả bôi đen, sao chép (`Ctrl+C`), tìm kiếm ngữ nghĩa (`Ctrl+F`), và tương thích máy in ấn DPI cao.
2. **Khớp Ánh Xạ Phân Đoạn 1-1 (Run & Segment-Level Mapping)**:
   - Từng câu tiếng Anh tương ứng với đúng câu tiếng Việt dịch về mặt ngữ nghĩa và vị trí thị giác.
3. **Phù Hợp Với Môi Trường Đọc Đa Dạng**:
   - Xem trên thiết bị di động, máy đọc sách, in ấn khổ đôi (2-up), hoặc hiển thị trong phòng đọc sách 3D tương tác.

---

## 2. Layout A — Đối Trang (Facing Pages / 2-Up Spread)

### 2.1. Mục Đích & Trải Nghiệm Người Đọc
Mô phỏng trải nghiệm đọc sách xuất bản kinh điển của các tác phẩm song ngữ:
- **Trang Trái**: Toàn bộ bản gốc tiếng Anh giữ nguyên vẹn 100% định dạng, hình ảnh, font chữ và siêu liên kết.
- **Trang Phải**: Bản dịch tiếng Việt được dàn trang thích ứng tương đương, giữ nguyên vị trí khối tương ứng.
- Khi người đọc lật sách hoặc mở chế độ Two-Page View trên Adobe Acrobat / Foxit Reader / Browser, hai trang luôn mở ra song song trước mắt.

### 2.2. Hai Định Dạng Xuất Bản

1. **Tệp Sách Đối Trang (`facing_book.pdf`)**:
   - Sử dụng khổ trang đơn tiêu chuẩn ($612 \times 792 \text{ pt}$ hoặc khổ gốc).
   - Thứ tự trang:
     - Trang 1: Trang bìa (Cover) đứng đơn độc lập.
     - Trang 2: Trang 1 Gốc (EN) — Nằm bên trái (Verso).
     - Trang 3: Trang 1 Dịch (VI) — Nằm bên phải (Recto).
     - Trang 4: Trang 2 Gốc (EN)...
   - *Ưu điểm*: Tương thích tự nhiên với mọi trình đọc PDF và phòng đọc 3D mà không làm thay đổi tỷ lệ khung hình gốc.

2. **Tệp Khổ Đôi 2-Up Sheet (`facing_sheet.pdf`)**:
   - Gộp trực tiếp 2 trang đơn vào 1 trang rộng:
     $$W_{\text{sheet}} = W_{\text{EN}} + W_{\text{VI}}, \quad H_{\text{sheet}} = \max(H_{\text{EN}}, H_{\text{VI}})$$
   - Sử dụng lệnh `page.show_pdf_page(rect_left, src_doc, p)` và `page.show_pdf_page(rect_right, trn_doc, p)`.
   - *Ưu điểm*: Xem hoàn hảo trên màn hình máy tính ngang (Desktop Monitor) hoặc dùng để in ấn dàn trang báo chí.

---

## 3. Layout B — Xen Đoạn (Interleaved Flow)

### 3.1. Mục Đích & Trải Nghiệm Người Đọc
Phù hợp cho tài liệu học tập, nghiên cứu chuyên sâu, đối chiếu từ vựng hoặc đọc trên màn hình điện thoại (Mobile Flow):
- Trong cùng một trang, mỗi đoạn văn tiếng Anh đi liền ngay sau là đoạn dịch tiếng Việt.
- Độc giả không cần đảo mắt giữa 2 trang mà đọc liền mạch từng ý.

### 3.2. Quy Chuẩn Kiểu Chữ (Typography Styling)
- **Đoạn Tiếng Anh Gốc**:
  - Font: Giữ nguyên họ font gốc hoặc font trung tính chất lượng cao.
  - Màu sắc: `#2a2e30` (Màu than đen chuẩn xuất bản).
- **Đoạn Tiếng Việt Dịch**:
  - Font: `Plus Jakarta Sans` nhúng CID tĩnh.
  - Màu sắc nhận diện: Teal `#0a7a8c` hoặc Brand Blue `#0aa9bf`.
  - Kiểu chữ: Có thể nghiêng nhẹ hoặc thụt lề 8 pt để phân tách thị giác rõ ràng.
- **Khoảng cách nhịp thở**:
  - Khoảng cách giữa EN và VI trong cùng 1 cụm: $4 \text{ pt}$.
  - Khoảng cách giữa 2 cụm khác nhau: $12 \text{ pt}$.

---

## 4. Lệnh Vận Hành Tự Động

```bash
# Xuất cả 2 phiên bản Facing Book và Facing Sheet:
python scripts/cli.py bilingual --source original.pdf --trans vietnamese.pdf --mode facing --out-book output/facing_book.pdf --out-sheet output/facing_sheet.pdf

# Xuất phiên bản Xen Đoạn:
python scripts/cli.py bilingual --source original.pdf --trans vietnamese.pdf --mode interleaved --out-interleaved output/interleaved.pdf

# Xuất tất cả:
python scripts/cli.py bilingual --source original.pdf --trans vietnamese.pdf --mode all
```
