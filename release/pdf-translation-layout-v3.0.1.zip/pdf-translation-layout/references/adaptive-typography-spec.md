# Đặc Tả Kỹ Thuật Dàn Trang Thích Ứng (Adaptive Typography Specification v2.0)

Tài liệu này cung cấp công thức toán học và thuật toán chuẩn để xử lý độ nở văn bản (~12%–18%) trong các tài liệu PDF vector cố định kích thước trang.

---

## 1. Ngân Sách Typography Vi Mô (Micro-Typographic Budgets)

Khi văn bản dịch từ tiếng Anh sang tiếng Việt dài hơn, thuật toán phải tuân theo thứ tự điều chỉnh có kiểm soát sau đây:

| Thứ tự ưu tiên | Thuộc tính điều chỉnh | Ngưỡng cho phép | Tác động thị giác |
|---|---|---|---|
| **Ưu tiên 1** | Mở rộng lề phải dòng (`x1_max`) | $+6.0 \text{ pt} \rightarrow +18.0 \text{ pt}$ (khi cách lề an toàn $> 12 \text{ pt}$) | Không làm giảm cỡ chữ, tận dụng khoảng trắng dư thừa |
| **Ưu tiên 2** | Tinh chỉnh khoảng cách dòng (`leading`) | Giảm tối đa $-1.5 \text{ pt}$ (ví dụ từ `15.8 pt` xuống `14.3 pt`) | Giữ nguyên tỷ lệ chữ, chỉ thu hẹp khoảng hở giữa các dòng |
| **Ưu tiên 3** | Giảm khoảng trống đoạn (`space_after`) | Giảm từ $8.24 \text{ pt}$ xuống $4.0 \text{ pt}$ (tối đa $-50\%$) | Gom các đoạn thân bài sát lại gần nhau hơn |
| **Ưu tiên 4** | Hạ tỷ lệ Typography theo Bậc thang (`sc`) | $sc \in [1.00, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.76, 0.73, 0.70, 0.67]$ | Giảm đồng thời font size, leading và space_after theo tỷ lệ vàng |

> [!CAUTION]
> Tuyệt đối không bao giờ giảm cỡ chữ đơn lẻ mà không điều chỉnh leading tương ứng, vì sẽ gây hiện tượng dòng chữ bị dính vào nhau hoặc mất cân đối baseline.

---

## 2. Thuật Toán Bẻ Dòng Né Ảnh Hai Phía (Bilateral Line-Wrapping Algorithm)

Cho một khối văn bản có các tham số:
- Tọa độ gốc: $x_0$, $x_{1,\max}$, $y_{start}$
- Vùng ảnh cần né bên phải: $R_{right} = [ax_0, ay_0, ax_1, ay_1]$
- Vùng ảnh cần né bên trái: $R_{left} = [lx_0, ly_0, lx_1, ly_1]$

Tại mỗi dòng thứ $k$ có đỉnh dòng là $y_{top} = y_{start} + k \times \text{leading}$:

$$\text{Line Bounds } [lx_0^{(k)}, lx_1^{(k)}] = \begin{cases}
lx_0^{(k)} = \begin{cases} \max(x_0, ly_1) & \text{nếu } (y_{top} + \text{size}) \ge ly_0 \text{ và } y_{top} \le ly_1 \\ x_0 & \text{ngược lại} \end{cases} \\
lx_1^{(k)} = \begin{cases} \min(x_{1,\max}, ax_0 - 4.0) & \text{nếu } (y_{top} + \text{size}) \ge ay_0 \text{ và } y_{top} \le ay_1 \\ x_{1,\max} & \text{ngược lại} \end{cases}
\end{cases}$$

---

## 3. Quy Tắc Giao Cắt Ngang Cho Khối Dưới Ảnh (Horizontal Overlap Rule)

Để ngăn việc đẩy nhầm các khối chữ nằm ngang hàng với ảnh (`z_side`) xuống dưới đáy ảnh (`z_below`):

$$\text{Horizontal Overlap } \Delta_x = \min(x_1, \text{img}.x_1) - \max(x_0, \text{img}.x_0)$$

$$\text{Chỉ dịch tọa độ } y_0 \text{ nếu: } \Delta_x > 20.0 \text{ pt} \quad \text{và} \quad \text{img}.y_0 < y_0 \le \text{img}.y_1 + 4.0 \text{ pt}$$

Khi thỏa mãn:
$$y_{0,\text{new}} = \text{img}.y_1 + 5.0 \text{ pt}$$

---

## 4. Công Thức Căn Giữa Dọc Cho Ô Bảng (Table Cell Vertical Centering)

Cho một ô bảng có giới hạn chữ nhật $[cx_0, cy_0, cx_1, cy_1]$:
- Chiều cao khả dụng: $H_{avail} = cy_1 - cy_0$
- Tổng chiều cao khối văn bản sau khi ngắt $m$ dòng: $H_{text} = y_{bot}^{(m)} - y_{top}^{(1)}$

Nếu văn bản ngắt thành nhiều dòng và đáy dòng cuối chạm sát mép dưới ($y_{bot}^{(m)} > cy_1 - 2.0 \text{ pt}$) nhưng $H_{text} \le H_{avail} - 2.0 \text{ pt}$:

$$y_{start,\text{new}} = cy_0 + \max\left(2.0, \frac{H_{avail} - H_{text}}{2}\right)$$

Nhờ đó, văn bản trong ô bảng luôn nằm chính giữa tâm dọc của ô, cách đều mép trên và mép dưới.
