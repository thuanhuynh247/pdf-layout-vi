# Quy Trình Vận Hành Sản Xuất PDF Thích Ứng (Production Runbook v2.0)

Runbook này chuẩn hóa 8 giai đoạn thực hiện dự án dịch và dàn trang PDF theo chuẩn [SKILL.md](../SKILL.md). Tuyệt đối tuân thủ nguyên tắc: **Tập tin PDF nguồn là bất biến (Read-only)**.

---

## Giai đoạn A: Tiếp nhận & Kiểm kê Kỹ thuật (Inventory & Extraction)

1. **Khởi tạo môi trường & Bất biến tập tin nguồn**:
   - Đặt tập tin PDF nguồn vào thư mục dự án gốc (ví dụ: `80000-Hours-Starter-Guide.pdf`).
   - Tính toán và lưu mã băm SHA256 để đảm bảo tính bất biến:
     ```bash
     python -c "import hashlib; print(hashlib.sha256(open('input.pdf','rb').read()).hexdigest())"
     ```
2. **Kiểm kê Cơ khí & Tài nguyên**:
   - Chạy `scripts/inventory_extractor.py` để trích xuất:
     - Số trang chính xác, kích thước `MediaBox` và `CropBox` (ví dụ: `612.0 × 792.0 pt`).
     - Danh mục font nhúng, mã subset, kiểu mã hóa (`Identity-H`, `WinAnsiEncoding`).
     - Phát hiện các đoạn in nghiêng ma trận hình học Skia: `Tm = [1 0 0.25 -1 x y]`.
     - Danh mục toàn bộ hình ảnh (`xref`, kích thước pixel, tọa độ xuất hiện trên trang).
     - Danh mục đồ họa vector (đường kẻ, khung bảng, đường cong Bézier).
     - Danh mục liên kết (`LINK_URI` và `LINK_GOTO`).
   - Lưu trữ toàn bộ vào `data/full_book_raw.json` và `data/full_book_images.json`.

---

## Giai đoạn B: Chuẩn hóa Thuật ngữ & Cấu trúc Dữ liệu Dịch (Glossary & Batching)

1. **Lập Bảng thuật ngữ chuyên ngành (Glossary)**:
   - Tạo `docs/glossary.md` và `data/glossary.json` trước khi bắt đầu dịch.
   - Định nghĩa quy tắc mở ngoặc từ tiếng Anh ở lần xuất hiện đầu tiên (ví dụ: *Lòng vị tha hiệu quả (Effective Altruism)*, *Rủi ro hiện sinh (Existential Risk)*).
2. **Phân chia Đợt dịch (Batching)**:
   - Với tài liệu dài (> 30 trang), không dịch toàn bộ trong một lượt để tránh chạm trần token/quota.
   - Chia tài liệu thành các đợt 20–25 trang (ví dụ: 8 Batches cho 163 trang).
   - Lưu trữ cấu trúc JSON 1-1 theo khối chữ (`block_id`) và danh sách các đoạn (`runs`).
   - Bảo toàn chính xác các trường `style` (`regular`, `medium`, `semibold`, `italic`, `bold_italic`, `superscript`), mã màu `#2a2e30` / `#0aa9bf` và target `link`.

---

## Giai đoạn C: Lập Bản đồ Typography & Chọn Font Dự phòng (Style Mapping)

1. **Nguyên tắc chọn Font**:
   - Nếu PDF nguồn sử dụng font độc quyền bị subset (như `Avenir LT Pro`), lựa chọn font Geometric Sans mã nguồn mở tương đương có hỗ trợ tiếng Việt đầy đủ (khuyên dùng: **Plus Jakarta Sans**).
   - Kiểm tra bộ font tĩnh đầy đủ 5 biến thể: `Regular`, `Medium`, `SemiBold`, `Italic`, `SemiBoldItalic`.
2. **Đo đạc x-height & Tỷ lệ hiển thị**:
   - Tạo file `docs/style-map.md` ghi nhận tỷ lệ tương quan cỡ chữ giữa nguồn và đích:
     - Tiêu đề chính (H1): `36 pt` (hoặc `30 pt` khi dài)
     - Tiêu đề chương (H2): `17.2 pt` (gốc `18.5 pt`)
     - Tiêu đề mục (H3): `13.5 pt`
     - Thân bài (Body): `10.8 pt` – `11.1 pt`, `leading = 15.2 pt – 15.8 pt`
     - Chú thích chân trang (Footnote): `9.3 pt`, `leading = 12.2 pt`

---

## Giai đoạn D: Việt hóa Biểu đồ & Hình ảnh (Figure Localization)

1. **Quy trình tái lập đồ họa bằng PIL/Pillow**:
   - Với các trang có biểu đồ/đồ thị (như biểu đồ cột, đồ thị hàm mũ, sơ đồ 2 chiều):
     1. Lấy mẫu màu nền trực tiếp từ vùng pixel lân cận (`im.getpixel()`).
     2. Dùng `draw.rectangle()` xóa sạch các hộp nhãn tiếng Anh cũ.
     3. Tải font `PlusJakartaSans-Medium.ttf` hoặc `PlusJakartaSans-SemiBold.ttf` ở kích thước tương ứng.
     4. Ghi đè nhãn tiếng Việt chuẩn thuật ngữ.
     5. Với các nhãn trục dọc (Y-axis), dùng kỹ thuật render trên ảnh trong suốt và xoay 90° CCW:
        ```python
        txt_img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        # draw text...
        rot_img = txt_img.rotate(90, expand=True, resample=Image.BICUBIC)
        im.paste(rot_img, (x, y), rot_img)
        ```
2. **Lưu trữ asset đã Việt hóa**:
   - Xuất file PNG chất lượng cao vào `assets/figures/*_chart_vi.png`.
   - Cập nhật ánh xạ thay thế hình ảnh vào `full_book_translations.json`:
     ```json
     "replace_images": [
       {"xref": 104, "path": "assets/figures/page_013_chart_vi.png"}
     ]
     ```

---

## Giai đoạn E: Dàn trang Thích ứng Theo Phân Vùng (Zone-Bounded Adaptive Layout)

1. **Làm sạch Content Stream (`clean_page_stream`)**:
   - Xóa bỏ toàn bộ các khối chữ tiếng Anh cũ `BT ... ET`.
   - Xóa bỏ các đường cong Bézier vector vẽ chữ (ví dụ: Trang 4).
   - Lọc bỏ các hộp chữ nhật trắng lót dòng (`1 1 1 rg ... re f` với `h < 100 pt`) để khôi phục nguyên vẹn nền xám `#f5f5f5` và khung viền `#cbcbcb` của các bảng dữ liệu.
2. **Phân vùng dọc (Vertical Zones)**:
   - Gom các khối văn bản liền kề thành từng Zone độc lập (`z_above`, `z_side`, `z_below`, `z_foot`).
   - Thiết lập `zone_y1_max` cho từng vùng để ngăn hiện tượng dồn dòng làm tràn trang.
3. **Thuật toán co giãn Typography theo Bậc thang**:
   - Với mỗi Zone, thử nghiệm các mức tỷ lệ $sc \in [1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.76, 0.73, 0.70, 0.67]$.
   - Tự động hạ cỡ chữ `size * sc`, giãn dòng `leading * sc` và khoảng cách đoạn `space_after * sc` cho đến khi tất cả các dòng nằm gọn bên trong `zone_y1_max`.
4. **Tránh ảnh chân dung hai phía (Bilateral Wrap Avoidance)**:
   - Dùng `wrap_avoid_rect` cho ảnh bên phải và `wrap_avoid_left_rect` cho ảnh bên trái.
   - Chỉ đẩy tọa độ khối chữ xuống dưới ảnh nếu có giao cắt ngang `h_overlap > 20.0 pt`.
5. **Đảo ngược thứ tự Footnote theo trục Y**:
   - Sắp xếp các khối trong `z_foot` theo chiều tăng dần của `y0` để các footnote luôn chảy xuôi từ trên xuống dưới một cách tự nhiên.

---

## Giai đoạn F: Biên dịch & Tối ưu hóa Bộ nhớ PyMuPDF

1. **Nhúng Font tĩnh & Gắn liên kết**:
   - Nhúng subset CID Font `Plus Jakarta Sans` trên từng trang.
   - Chèn văn bản theo tọa độ baseline đã tính toán.
   - Gắn lại liên kết web (`LINK_URI`) và liên kết nội bộ (`LINK_GOTO`) vào đúng vùng `Rect` của từ ngữ tiếng Việt.
2. **Tối ưu hóa tập tin xuất xưởng**:
   - Gọi `doc.subset_fonts()`.
   - Lưu tập tin bằng lệnh `doc.save(out_path, garbage=1, deflate=True)`. Tránh dùng `garbage=3` trên tài liệu lớn để ngăn chặn lỗi `MemoryError`.

---

## Giai đoạn G: Kiểm định QA 4 Tầng Tự Động (Automated QA Gate)

Chạy script kiểm định tự động:
```bash
python scripts/qa_verifier.py
```
Yêu cầu đạt chuẩn **100% PASS** trước khi nghiệm thu:
1. **Mechanical**: 163 / 163 trang, khổ `612 × 792 pt`, font CID nhúng đủ.
2. **Geometric**: 0 Safe margin violations, 0 Image overlaps, 0 Table cell violations, 0 Block collisions.
3. **Content**: 0 Replacement chars (`\ufffd`, `□`), trích xuất toàn văn tiếng Việt sạch sẽ.
4. **Visual**: Render ảnh so sánh song song 130 DPI cho toàn bộ các trang tiêu biểu.

---

## Giai đoạn H: Nghiệm thu & Bàn giao (Deliverables Hand-off)

1. Cập nhật `docs/qa-checklist-report.md` và `walkthrough.md`.
2. Bàn giao tập tin PDF hoàn chỉnh kèm bảng thuật ngữ và mã nguồn tái lập.
