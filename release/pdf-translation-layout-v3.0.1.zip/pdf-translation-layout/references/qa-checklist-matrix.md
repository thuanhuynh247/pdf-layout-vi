# Ma Trận Tiêu Chuẩn Kiểm Định QA 4 Tầng (QA Checklist Matrix v2.0)

Tài liệu này xác định ma trận kiểm định chất lượng bắt buộc trước khi phát hành bất kỳ tập tin PDF nào xuất xưởng từ quy trình [SKILL.md](../SKILL.md).

---

## Bảng Ma Trận Kiểm Định 4 Tầng

| Tầng | Hạng mục kiểm tra | Phương pháp đo lường | Ngưỡng vượt qua (Pass Criteria) | Trạng thái bắt buộc |
|---|---|---|---|---|
| **Tầng 1: Cơ khí** | Số trang tài liệu | `len(doc_out) == len(doc_src)` | Bằng đúng số trang gốc, không sinh trang trắng | **CRITICAL** |
| | Kích thước MediaBox | `page.rect == [0, 0, W, H]` | Khớp 100% kích thước điểm (pt) của từng trang | **CRITICAL** |
| | Nhúng Font tĩnh | `page.get_fonts()` | Toàn bộ font có `Identity-H`, nhúng subset CID | **CRITICAL** |
| | Dung lượng file tối ưu | `os.path.getsize()` | Tối ưu nén deflate, không vượt quá $3\times$ file gốc | **HIGH** |
| **Tầng 2: Hình học** | Lề an toàn trang | `rx0 >= 45, rx1 <= 567, ry0 >= 45, ry1 <= 758` | **0** text run chạm hoặc vượt ra ngoài lề | **CRITICAL** |
| | Giao cắt hình ảnh | `run_rect & img_rect` | **0** dòng chữ đè lên ảnh chân dung/biểu đồ | **CRITICAL** |
| | Biên giới hạn ô bảng | `run_rect ⊆ cell_bounds` | **0** dòng chữ tràn khỏi biên ô trên Trang 78 & 81 | **CRITICAL** |
| | Va chạm giữa các khối | `block1_rect & block2_rect` | **0** cặp khối chữ giao cắt trên cùng một trang | **CRITICAL** |
| **Tầng 3: Text Layer** | Ký tự Tofu / Hỏng dấu | `count("\ufffd") + count("□")` | **0** ký tự lỗi trên toàn bộ tài liệu | **CRITICAL** |
| | Độ toàn vẹn văn bản | `page.get_text("text")` | Trích xuất được văn bản tiếng Việt đầy đủ thanh điệu | **CRITICAL** |
| | Khôi phục Hyperlinks | `page.get_links()` | Khớp 100% số lượng link web và link nội bộ | **HIGH** |
| **Tầng 4: Trực quan** | Đối chiếu song song | Render 130 DPI Side-by-Side | Bố cục mắt nhìn cân đối, phân cấp H1/H2/Body rõ | **HIGH** |
| | Độ hòa màu hình ảnh | So mẫu pixel vùng vá | Không có seam, không có viền trắng loang lổ | **HIGH** |
| | Nền xám ô bảng | Bảng Trang 78 & 81 | Nền `#f5f5f5` liền mạch, viền kẻ `#cbcbcb` nguyên | **HIGH** |
