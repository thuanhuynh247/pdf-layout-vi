# Đặc Tả Voice Studio & Reading Video Engine (v3.0 Broadcast Standard)

Tài liệu này định nghĩa chi tiết kiến trúc âm thanh VieNeu-TTS, cơ chế Nhân bản Giọng nói (Instant Voice Cloning) và Engine sản xuất Video Đọc Sách 1080p Broadcast Standard.

---

## 1. Voice Studio Đa Tầng (VieNeu-TTS v3 Ecosystem)

### 1.1. Thứ Tự Điều Hướng Động Cơ Tự Động (Auto Fallback Hierarchy)
Hệ thống quản trị giọng nói thông qua 3 tầng dự phòng tự động:
1. **Tầng 1 — VieNeu Cloud API (`api.vieneu.io`)**:
   - Được kích hoạt tự động nếu biến môi trường `VIENEU_API_KEY` khả dụng.
   - Cho tốc độ xử lý nhanh nhất và chất lượng âm thanh neural cao cấp nhất.
2. **Tầng 2 — VieNeu Local ONNX Engine (`v3nano`)**:
   - Chạy hoàn toàn offline cục bộ trên máy tính người dùng.
   - Tiêu thụ ít hơn 800 MB RAM, tối ưu hóa cho máy tính văn phòng hoặc môi trường bảo mật không kết nối internet.
3. **Tầng 3 — Edge-TTS Fallback**:
   - Dự phòng cho các trường hợp thiếu bộ nhớ hoặc môi trường không cài đặt thư viện neural cục bộ.

### 1.2. Thư Viện Giọng Đọc Sẵn Có (Ready-Made Voice Library)
- **Tiếng Việt**:
  - `Đức Trí`: Nam · Bắc · Truyện đọc truyền cảm (Mặc định cho sách phát triển bản thân & học thuật).
  - `Minh Quân`: Nam · Bắc · Giọng đọc tự nhiên, hiện đại.
  - `Trúc Ly`: Nữ · Bắc · Tự nhiên, êm dịu.
  - `Mỹ Duyên`: Nữ · Bắc · Kể chuyện diễn cảm.
  - `Anh Khôi`: Nam · Bắc · Giọng thuyết minh tài liệu.
  - `Ái Hân`: Nữ · Nam · Giọng phát thanh thời sự.
- **Tiếng Anh**:
  - `Andrew`: Nam · Mỹ bản ngữ (Tự nhiên, tốc độ chuẩn học thuật).
  - `Ava`: Nữ · Mỹ bản ngữ (Êm ái, rõ từng âm tiết).
  - `Adam`: Nam · VieNeu preset đọc tiếng Anh.

### 1.3. Nhân Bản Giọng Nói Tức Thì (Instant Voice Cloning 3–8 Giây)
Người dùng có thể sao chép bất kỳ chất giọng nào chỉ với 1 đoạn ghi âm mẫu ngắn:
```bash
python scripts/cli.py voice clone --name "MyVoice" --lang vi --ref sample.wav --ref-text "Câu thoại mẫu trong tệp ghi âm"
```
Hồ sơ giọng nói mới sẽ được lưu trữ tự động vào `voices/voices.json` để tái sử dụng xuyên suốt toàn bộ dự án.

---

## 2. Reading Video Engine 1080p Broadcast Standard

### 2.1. Kiến Trúc Single-Pass Broadcast (Khắc Phục Hoàn Toàn Lỗi Méo Tiếng)
Các video đọc sách tạo từ ảnh tĩnh thường gặp lỗi kinh điển là **âm thanh bị the thé / éo tiếng / pitch warp** do trượt xung đồng hồ giữa video và audio. Engine v3.0 áp dụng kiến trúc Single-Pass Broadcast chuẩn truyền hình:

1. **Khung Hình Cố Định (Constant Framerate 25.000 fps)**:
   - Thay vì để video ở mức 0.07 fps, FFmpeg nhân bản khung hình tĩnh ở tốc độ **25 khung hình/giây**.
   - Cài đặt chu kỳ keyframe định kỳ: `-g 50 -keyint_min 25` (mỗi 2 giây có 1 I-frame chuẩn).
   - Bộ giải mã video và audio luôn đồng bộ khóa cứng 100%, không bao giờ trượt clock.

2. **Chuẩn Âm Thanh Studio 48,000 Hz AAC**:
   - Master WAV được ghép nối ở 24,000 Hz với khoảng lặng thở tự nhiên $0.22 \text{s}$ giữa các câu.
   - Khi mã hóa MP4, FFmpeg thực hiện resample lên **48,000 Hz AAC 192 kbps** bằng bộ lọc SoXR chất lượng cao.
   - Loại bỏ hoàn toàn `-c copy` khi ghép các phân đoạn.

3. **Mã Hóa 1 Lượt Toàn Tệp (Single-Pass Full Stream)**:
   ```bash
   ffmpeg -y \
     -f concat -safe 0 -i concat_frames.txt \
     -i master_audio.wav \
     -r 25 \
     -c:v libx264 -pix_fmt yuv420p -preset veryfast -crf 22 \
     -g 50 -keyint_min 25 \
     -c:a aac -b:a 192k -ar 48000 \
     -movflags +faststart \
     -shortest \
     output_video.mp4
   ```

### 2.2. Hai Chế Độ Video Xuất Bản

1. **Chế Độ `mono_vi` (Đọc Toàn Bộ Tiếng Việt)**:
   - Hai trang sách gốc (EN) và dịch (VI) hiển thị song song.
   - Giọng đọc tiếng Việt (Đức Trí) đọc tuần tự từng đoạn.
   - Bounding box viền xanh ngọc `#00d8f0` highlight chính xác đoạn đang đọc trên trang tiếng Việt.
   - Phụ đề tiếng Việt hiển thị ở đáy màn hình với nhãn chương/đoạn rõ ràng.

2. **Chế Độ `bilingual` (Đọc Song Ngữ Đan Xen EN ➔ VI)**:
   - **Nhịp 1**: Giọng bản ngữ tiếng Anh (`Andrew`) đọc câu tiếng Anh $\rightarrow$ Highlight vàng hổ phách `#e5a93c` trên trang trái + Phụ đề tiếng Anh màu vàng.
   - **Nhịp 2**: Ngay sau đó, giọng tiếng Việt (`Đức Trí`) đọc câu dịch tương ứng $\rightarrow$ Highlight xanh ngọc `#00d8f0` trên trang phải + Phụ đề tiếng Việt màu trắng.
   - Trải nghiệm học ngoại ngữ và thẩm thấu nội dung vượt trội.
