# Cẩm Nang Tích Hợp `pdf-translation-layout` Vào OpenAI ChatGPT & Custom GPTs

Tài liệu này hướng dẫn cách tạo một **Custom GPT** độc quyền trên ChatGPT Store hoặc sử dụng trực tiếp tính năng **Advanced Data Analysis (Code Interpreter)** của ChatGPT để dịch và dàn trang PDF vector chất lượng xuất bản.

---

## 1. Cách Tạo Custom GPT Chuyên Dụng (Từng Bước)

Nếu bạn có tài khoản ChatGPT Plus, Team hoặc Enterprise, hãy làm theo các bước sau để tạo một Custom GPT riêng cho doanh nghiệp hoặc cá nhân:

### Bước 1: Mở Trình Quản Lý GPT
1. Truy cập [chatgpt.com/gpts/editor](https://chatgpt.com/gpts/editor).
2. Chọn tab **Configure**.

### Bước 2: Điền Thông Tin Cấu Hình
- **Name**: `PDF Vector Translation & Publishing Engine v3.0`
- **Description**: `Chuyên gia dịch thuật & dàn trang PDF vector thích ứng chuẩn xuất bản (Zero-Rasterization). Hỗ trợ dịch đơn ngữ, song ngữ Đối trang 1-1, Xen đoạn, lồng tiếng VieNeu-TTS và video đọc sách 1080p.`
- **Instructions**:
  Mở tệp [`chatgpt-system-instructions.md`](chatgpt-system-instructions.md) trong thư mục này, sao chép toàn bộ nội dung trong mục **2. Instructions** và dán vào ô **Instructions** của GPT.

### Bước 3: Kích Hoạt Năng Lực (Capabilities)
- [x] **Code Interpreter & Data Analysis** *(Bắt buộc: ChatGPT cần môi trường Python để chạy thư viện PyMuPDF và xử lý PDF)*.
- [x] **Web Browsing** *(Khuyên dùng: để tra cứu thuật ngữ chuyên ngành)*.

### Bước 4: Tải Lên Tệp Tri Thức (Knowledge Files)
Tải các tệp sau từ thư mục `references/` lên mục **Knowledge**:
- `references/adaptive-typography-spec.md`
- `references/bilingual-layout-spec.md`
- `references/qa-checklist-matrix.md`

### Bước 5: Đặt Câu Mẫu Mở Đầu (Conversation Starters)
1. `Dịch tài liệu PDF này sang tiếng Việt, bảo tồn 100% vector layout gốc.`
2. `Tạo bản PDF song ngữ đối trang (Facing Pages: Trái EN - Phải VI).`
3. `Tạo bản PDF song ngữ xen đoạn (Interleaved Flow) để học ngoại ngữ.`
4. `Kiểm tra chất lượng file PDF dịch này qua Cổng kiểm định QA 4 tầng.`

---

## 2. Cách Sử Dụng Trực Tiếp Trên ChatGPT (Không Cần Custom GPT)

Nếu không tạo Custom GPT, bạn vẫn có thể sử dụng trực tiếp trên ChatGPT thông qua cửa sổ chat thông thường:

1. Đính kèm tệp PDF cần dịch vào khung chat.
2. Dán đoạn Prompt sau:
   ```text
   Tôi muốn bạn dịch tài liệu PDF này sang tiếng Việt theo triết lý "Zero-Rasterization":
   1. Sử dụng thư viện PyMuPDF (fitz) trong môi trường Python Code Interpreter.
   2. Giữ nguyên 100% Vector Text Layer thật (chữ có thể bôi đen và tìm kiếm được).
   3. Giữ nguyên kích thước trang, hình ảnh minh họa và bảng biểu.
   4. Dịch các khối văn bản và ghi đè bằng font Unicode thích hợp, điều chỉnh cỡ chữ nếu tiếng Việt bị nở dài hơn.
   5. Xuất ra file PDF hoàn thiện và cung cấp link tải về cho tôi.
   ```
3. ChatGPT sẽ tự động viết code Python, chạy trong sandbox và trả về file PDF đã được dịch nguyên vẹn layout.

---

## 3. Các Giới Hạn Cần Lưu Ý Trên Nền Tảng ChatGPT

- **Giới hạn thời gian Code Interpreter**: Môi trường Python của ChatGPT giới hạn thời gian thực thi mã nguồn khoảng 60–120 giây cho mỗi lượt. Với sách dài hàng trăm trang, hãy yêu cầu ChatGPT xử lý theo từng chương hoặc từng đoạn 10–20 trang.
- **Thư viện âm thanh**: Môi trường sandbox của OpenAI không cài sẵn FFmpeg đầy đủ với bộ giải mã H.264 bản quyền. Do đó, tính năng xuất Video đọc sách 1080p và VieNeu-TTS chạy tốt nhất trên **Antigravity IDE** hoặc **Claude Code CLI** (chạy trên máy cục bộ của người dùng).
