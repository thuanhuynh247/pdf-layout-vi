# Bắt đầu tại đây — pdf-translation-layout v3.0.1

Cảm ơn bạn đã tải gói kỹ năng. Làm theo 3 bước dưới đây (khoảng 5 phút).

## Bước 1 — Chuẩn bị máy
- Python 3.10 trở lên (kiểm tra: `python --version`).
- `ffmpeg` (chỉ cần nếu xuất video đọc sách).
- Mở terminal tại thư mục `pdf-translation-layout` vừa giải nén, chạy:
  ```bash
  pip install -r requirements.txt
  ```

## Bước 2 — Cài vào nền tảng AI bạn dùng

| Nền tảng | Cách cài | Hướng dẫn chi tiết |
|---|---|---|
| **Claude Code** | Mở terminal trong thư mục này và gõ `claude` (tự đọc `CLAUDE.md`), hoặc chép thư mục vào `~/.claude/skills/` | `GUIDE_CLAUDE.md` |
| **Antigravity IDE** | Chép thư mục vào thư mục skills của Antigravity, gõ `/pdf-translation-layout` trong khung chat | `GUIDE_ANTIGRAVITY.md` |
| **ChatGPT** | Tạo Custom GPT, dán phần Instructions từ `chatgpt-system-instructions.md`, bật Code Interpreter | `GUIDE_CHATGPT.md` |

## Bước 3 — Chạy thử
```bash
python scripts/cli.py inspect --source tai-lieu.pdf --out-dir data/
```
Nếu thấy dòng `Kiểm kê hoàn tất: … trang, … ảnh, … fonts.` là đã sẵn sàng. Sau đó chỉ cần nói với AI:
> "Dịch tài liệu tai-lieu.pdf sang tiếng Việt, giữ nguyên layout, rồi chạy QA."

## Lưu ý
- Tài liệu bạn dịch phải là tài liệu bạn có quyền dịch / sử dụng.
- ChatGPT không xuất được video (sandbox thiếu ffmpeg đầy đủ) — dùng Claude Code hoặc Antigravity cho tính năng này.
- Gặp lỗi? Trả lời email đăng ký và đính kèm nội dung lỗi.

Phát hành miễn phí theo giấy phép MIT bởi Huỳnh Anh Thuận.
