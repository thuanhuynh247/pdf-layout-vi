"""
inventory_extractor.py
Trích xuất toàn diện thông số kỹ thuật, font chữ, hình ảnh, vector và văn bản từ PDF nguồn.
"""

import argparse
import json
import os
import pymupdf as fitz


def extract_inventory(pdf_path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    doc = fitz.open(pdf_path)

    metadata = {
        "file_name": os.path.basename(pdf_path),
        "page_count": len(doc),
        "pages_info": {},
        "all_images": [],
        "all_fonts": set(),
    }

    raw_pages = {}

    for pno in range(len(doc)):
        page = doc[pno]
        p_str = str(pno + 1)
        rect = page.rect

        # Images
        p_images = []
        for img in page.get_images():
            xref = img[0]
            for r in page.get_image_rects(xref):
                pix = fitz.Pixmap(doc, xref)
                p_images.append({
                    "xref": xref,
                    "bbox": [round(v, 2) for v in r],
                    "width": pix.width,
                    "height": pix.height,
                    "colorspace": pix.colorspace.name if pix.colorspace else "Unknown",
                })
                metadata["all_images"].append({
                    "page": pno + 1,
                    "xref": xref,
                    "bbox": [round(v, 2) for v in r],
                    "width": pix.width,
                    "height": pix.height,
                })

        # Fonts
        p_fonts = []
        for f in page.get_fonts():
            p_fonts.append(f[3])
            metadata["all_fonts"].add(f[3])

        # Links
        links = []
        for lk in page.get_links():
            lk_dict = {
                "kind": lk.get("kind"),
                "from": [round(v, 2) for v in lk.get("from", [])],
                "uri": lk.get("uri"),
                "page": lk.get("page"),
            }
            links.append(lk_dict)

        # Text blocks
        text_page = page.get_text("dict")
        lines_out = []
        for blk in text_page.get("blocks", []):
            if "lines" not in blk:
                continue
            for ln in blk["lines"]:
                spans_out = []
                line_text = ""
                for sp in ln["spans"]:
                    t = sp["text"]
                    line_text += t
                    spans_out.append({
                        "text": t,
                        "font": sp["font"],
                        "size": round(sp["size"], 2),
                        "color": f"#{sp['color']:06x}",
                        "flags": sp["flags"],
                        "bbox": [round(v, 2) for v in sp["bbox"]],
                    })
                if line_text.strip():
                    lines_out.append({
                        "text": line_text,
                        "x0": round(ln["bbox"][0], 2),
                        "y0": round(ln["bbox"][1], 2),
                        "x1": round(ln["bbox"][2], 2),
                        "y1": round(ln["bbox"][3], 2),
                        "spans": spans_out,
                    })

        raw_pages[p_str] = {
            "page": pno + 1,
            "width": rect.width,
            "height": rect.height,
            "images": p_images,
            "fonts": p_fonts,
            "links": links,
            "lines": lines_out,
        }

        metadata["pages_info"][p_str] = {
            "rect": [rect.x0, rect.y0, rect.width, rect.height],
            "image_count": len(p_images),
            "font_count": len(p_fonts),
            "link_count": len(links),
            "line_count": len(lines_out),
        }

    metadata["all_fonts"] = sorted(list(metadata["all_fonts"]))

    with open(os.path.join(out_dir, "inventory_summary.json"), "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    with open(os.path.join(out_dir, "full_book_raw.json"), "w", encoding="utf-8") as f:
        json.dump(raw_pages, f, ensure_ascii=False, indent=2)

    with open(os.path.join(out_dir, "full_book_images.json"), "w", encoding="utf-8") as f:
        json.dump(metadata["all_images"], f, ensure_ascii=False, indent=2)

    total_pages = len(doc)
    doc.close()
    print(f"Kiểm kê hoàn tất: {total_pages} trang, {len(metadata['all_images'])} ảnh, {len(metadata['all_fonts'])} fonts.")
    print(f"Dữ liệu đã lưu tại: {out_dir}")


def main():
    parser = argparse.ArgumentParser(description="Trích xuất thông số kỹ thuật PDF nguồn.")
    parser.add_argument("--input", "-i", required=True, help="Đường dẫn file PDF nguồn")
    parser.add_argument("--output", "-o", default="data", help="Thư mục xuất dữ liệu JSON")
    args = parser.parse_args()

    extract_inventory(args.input, args.output)


if __name__ == "__main__":
    main()
