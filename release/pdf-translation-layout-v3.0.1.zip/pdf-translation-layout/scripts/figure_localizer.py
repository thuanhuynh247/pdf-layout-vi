"""
figure_localizer.py
Công cụ Việt hóa đồ họa, sơ đồ và biểu đồ chất lượng cao với PIL/Pillow.
Hỗ trợ lấy mẫu nền tự động, xóa nhãn tiếng Anh, và chèn nhãn tiếng Việt (kèm xoay 90 độ CCW).
"""

import argparse
import json
import os
from PIL import Image, ImageDraw, ImageFont


def draw_rotated_text(im, text, font, fill, center_xy, angle=90):
    """Render chữ trên ảnh RGBA trong suốt rồi xoay bicubic để tránh răng cưa."""
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)
    bb = d.textbbox((0, 0), text, font=font)
    tw, th = bb[2] - bb[0] + 16, bb[3] - bb[1] + 16
    txt_im = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    td = ImageDraw.Draw(txt_im)
    td.text((8 - bb[0], 8 - bb[1]), text, font=font, fill=fill)
    rot_im = txt_im.rotate(angle, expand=True, resample=Image.BICUBIC)
    rw, rh = rot_im.size
    px = int(center_xy[0] - rw / 2.0)
    py = int(center_xy[1] - rh / 2.0)
    im.paste(rot_im, (px, py), rot_im)


def localize_figure(image_path, config_path, output_path, font_path=None):
    im = Image.open(image_path).convert("RGBA")
    draw = ImageDraw.Draw(im)

    with open(config_path, encoding="utf-8") as f:
        cfg = json.load(f)

    # 1. Clean boxes
    for box in cfg.get("clean_boxes", []):
        rect = box["rect"]  # [x0, y0, x1, y1]
        sample_pt = box.get("sample_point", (rect[0] + 2, rect[1] + 2))
        fill_color = im.getpixel((sample_pt[0], sample_pt[1]))
        if "override_color" in box:
            fill_color = tuple(box["override_color"])
        draw.rectangle(rect, fill=fill_color)

    # 2. Draw text labels
    for lbl in cfg.get("labels", []):
        f_size = lbl.get("size", 28)
        f_file = lbl.get("font_file") or font_path
        font = ImageFont.truetype(f_file, f_size) if f_file else ImageFont.load_default()
        color = tuple(lbl.get("color", [42, 46, 48, 255]))
        text = lbl["text"]
        pos = lbl.get("pos", [100, 100])
        align = lbl.get("align", "left")
        angle = lbl.get("rotate", 0)

        if angle != 0:
            draw_rotated_text(im, text, font, color, pos, angle=angle)
        elif isinstance(text, list):
            # Multiline
            line_gap = lbl.get("line_gap", f_size * 1.3)
            total_h = (len(text) - 1) * line_gap
            start_y = pos[1] - total_h / 2.0 if align == "center_y" else pos[1]
            for idx, line in enumerate(text):
                bb = draw.textbbox((0, 0), line, font=font)
                w = bb[2] - bb[0]
                lx = pos[0] - w if align == "right" else (pos[0] - w / 2.0 if align == "center" else pos[0])
                ly = start_y + idx * line_gap
                draw.text((lx, ly), line, font=font, fill=color)
        else:
            bb = draw.textbbox((0, 0), text, font=font)
            w = bb[2] - bb[0]
            lx = pos[0] - w if align == "right" else (pos[0] - w / 2.0 if align == "center" else pos[0])
            draw.text((lx, pos[1]), text, font=font, fill=color)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    im.convert("RGB").save(output_path, "PNG", optimize=True)
    print(f"Đã Việt hóa biểu đồ: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Việt hóa nhãn hình ảnh/biểu đồ chuẩn xác.")
    parser.add_argument("--image", "-i", required=True, help="Đường dẫn ảnh PNG nguồn")
    parser.add_argument("--config", "-c", required=True, help="Đường dẫn file cấu hình JSON nhãn")
    parser.add_argument("--output", "-o", required=True, help="Đường dẫn ảnh PNG kết xuất")
    parser.add_argument("--font", "-f", default=None, help="Đường dẫn font chữ TTF mặc định")
    args = parser.parse_args()

    localize_figure(args.image, args.config, args.output, args.font)


if __name__ == "__main__":
    main()
