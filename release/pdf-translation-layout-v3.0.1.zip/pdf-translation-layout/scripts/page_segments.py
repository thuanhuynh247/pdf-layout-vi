#!/usr/bin/env python3
"""
page_segments.py — Trích xuất các đoạn đọc (reading segments) theo thứ tự đọc từ một trang PDF vector.

Mỗi segment gồm: bbox (pt, toạ độ trang), văn bản hiển thị, văn bản đã làm sạch cho TTS.
Dùng chung cho: highlight đồng bộ giọng đọc trong video, audio theo trang của phòng đọc 3D,
và đối chiếu song ngữ.

Nguyên tắc (không bịa dữ liệu): chỉ đọc chữ có thật trong text layer của PDF, không OCR, không suy diễn.

CLI:
  python page_segments.py --pdf book.pdf --pages 1,2,4 --lang en --out segments.json
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from pathlib import Path
from typing import Dict, List

import fitz  # PyMuPDF

URL_RE = re.compile(r"(https?://\S+|www\.\S+|\b\S+\.(?:org|com|net|io)/\S*)", re.I)
PAGE_NUM_RE = re.compile(r"^\s*\d{1,4}\s*$")

# Thuật ngữ đọc khó cho TTS → cách đọc tự nhiên
VI_SPEAK_MAP: Dict[str, str] = {
    "TL;DR": "Tóm lại",
    "80,000 Hours": "Tám mươi nghìn giờ",
    "80.000 Hours": "Tám mươi nghìn giờ",
    "CEO": "xi i âu",
    "AI": "ây ai",
    "%": " phần trăm",
}
EN_SPEAK_MAP: Dict[str, str] = {
    "TL;DR": "In short",
    "80,000 Hours": "eighty thousand hours",
    "e.g.": "for example",
    "i.e.": "that is",
    "etc.": "et cetera",
}


def _span_text(line: dict, median_size: float) -> str:
    out = []
    for s in line["spans"]:
        t = s["text"]
        # Bỏ chỉ số footnote (superscript): cỡ chữ nhỏ hẳn + chỉ là số
        if s["size"] < median_size * 0.78 and re.fullmatch(r"\s*[\d,\*†]+\s*", t):
            continue
        out.append(t)
    return "".join(out)


def clean_for_speech(text: str, lang: str, strip_en_parenthetical: bool = True) -> str:
    t = text.replace("\u00ad", "")
    t = re.sub(r"(\w)-\s+(\w)", r"\1\2", t)  # nối từ bị ngắt dòng bằng gạch nối
    t = URL_RE.sub("", t)
    t = t.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    t = re.sub(r"[•▪●◦■]", "", t)
    if lang == "vi" and strip_en_parenthetical:
        # Bản dịch thường giữ thuật ngữ gốc trong ngoặc: "(social impact)" → bỏ khi đọc để giọng Việt mượt hơn
        t = re.sub(r"\s*\((?:[A-Za-z][A-Za-z0-9 .,'&/\-]*)\)", "", t)
    speak = VI_SPEAK_MAP if lang == "vi" else EN_SPEAK_MAP
    for k, v in speak.items():
        if k == "AI" or k == "CEO":
            t = re.sub(rf"\b{k}\b", v, t)
        else:
            t = t.replace(k, v)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\s+([,.;:!?])", r"\1", t)
    return t


def extract_page_segments(page: "fitz.Page", lang: str, min_chars: int = 2) -> List[dict]:
    d = page.get_text("dict", sort=True)
    sizes = [s["size"] for b in d["blocks"] if b["type"] == 0 for l in b["lines"] for s in l["spans"] if s["text"].strip()]
    median = statistics.median(sizes) if sizes else 11.0
    H = page.rect.height
    segs: List[dict] = []
    for b in d["blocks"]:
        if b["type"] != 0:
            continue
        lines = [_span_text(l, median) for l in b["lines"]]
        text = " ".join(x.strip() for x in lines if x.strip())
        if len(text) < min_chars or PAGE_NUM_RE.match(text):
            continue
        x0, y0, x1, y1 = b["bbox"]
        # Bỏ header/footer lặp lại sát mép trang (chỉ khi rất ngắn)
        if (y1 < H * 0.045 or y0 > H * 0.955) and len(text) < 60:
            continue
        max_size = max((s["size"] for l in b["lines"] for s in l["spans"]), default=median)
        speech = clean_for_speech(text, lang)
        if not re.search(r"\w", speech):
            continue
        segs.append({
            "bbox": [round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2)],
            "text": text,
            "speech": speech,
            "size": round(max_size, 2),
            "kind": "heading" if max_size >= median * 1.35 else "body",
        })
    return segs


def split_sentences(text: str, max_chars: int = 220) -> List[str]:
    """Tách câu để TTS ổn định; câu quá dài được cắt ở dấu phẩy/chấm phẩy."""
    parts = re.split(r"(?<=[.!?…])\s+", text)
    out: List[str] = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        while len(p) > max_chars:
            cut = max(p.rfind(", ", 0, max_chars), p.rfind("; ", 0, max_chars), p.rfind(": ", 0, max_chars))
            if cut < max_chars * 0.4:
                cut = p.rfind(" ", 0, max_chars)
            if cut <= 0:
                break
            out.append(p[: cut + 1].strip())
            p = p[cut + 1:].strip()
        if p:
            out.append(p)
    return out


def parse_pages(spec: str, count: int) -> List[int]:
    if not spec or spec == "all":
        return list(range(1, count + 1))
    pages: List[int] = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-")
            pages.extend(range(int(a), int(b) + 1))
        elif part:
            pages.append(int(part))
    return [p for p in pages if 1 <= p <= count]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--pages", default="all", help="VD: 1,2,4-6 (số trang 1-based)")
    ap.add_argument("--lang", choices=["en", "vi"], required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    doc = fitz.open(a.pdf)
    res = {}
    for p in parse_pages(a.pages, doc.page_count):
        res[str(p)] = {"page": p, "rect": list(doc[p - 1].rect), "segments": extract_page_segments(doc[p - 1], a.lang)}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    n = sum(len(v["segments"]) for v in res.values())
    print(f"[segments] {len(res)} trang, {n} đoạn → {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
