#!/usr/bin/env python3
"""
reading_video_engine.py — Hệ thống sản xuất Video Đọc Sách Song Ngữ Tự Động v3.0:
Chuẩn phát hành Broadcast 1080p (1920x1080 @ 25fps constant, 48kHz AAC):
  - Hiển thị 2 trang sách song song (EN bên trái, VI bên phải) trên khung hình Full HD 1080p.
  - Tự động highlight đoạn văn bản đang đọc trên trang PDF tương ứng theo bounding box chính xác.
  - Phụ đề thông minh ngắt 2 dòng, nảy nhịp theo từng câu thoại.
  - Hỗ trợ 2 chế độ:
      1. mono_vi: Đọc toàn bộ tiếng Việt (VieNeu-TTS v3)
      2. bilingual: Đọc song ngữ đan xen (EN Andrew -> VI Đức Trí)
  - Kiến trúc Single-Pass Broadcast: Không lệch clock, không đứt gãy AAC priming, 0 méo/éo tiếng.

CLI:
  python reading_video_engine.py --source en.pdf --trans vi.pdf --manifest manifest.json --mode bilingual --out video.mp4
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional

import fitz  # PyMuPDF
import numpy as np
import soundfile as sf
from PIL import Image, ImageDraw, ImageFont

VIDEO_W = 1920
VIDEO_H = 1080
FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def get_font(size: int, bold: bool = False):
    name = "PlusJakartaSans-Bold.ttf" if bold else "PlusJakartaSans-Regular.ttf"
    fp = FONT_DIR / name
    if fp.is_file():
        try:
            return ImageFont.truetype(str(fp), size)
        except Exception:
            pass
    return ImageFont.load_default()


def wrap_text(text: str, max_chars_per_line: int = 90) -> List[str]:
    words = text.split()
    lines = []
    cur = []
    cur_len = 0
    for w in words:
        if cur_len + len(w) + 1 > max_chars_per_line and cur:
            lines.append(" ".join(cur))
            cur = [w]
            cur_len = len(w)
        else:
            cur.append(w)
            cur_len += len(w) + 1
    if cur:
        lines.append(" ".join(cur))
    return lines[:2]


def render_page_image(page: "fitz.Page", target_h: int = 1000) -> Image.Image:
    rect = page.rect
    zoom = target_h / rect.height
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    return Image.frombytes("RGB", [pix.width, pix.height], pix.samples)


def compose_video_frame(
    img_en: Image.Image,
    img_vi: Image.Image,
    active_bbox_en: Optional[List[float]],
    active_bbox_vi: Optional[List[float]],
    sub_title: str,
    sub_text: str,
    sub_color: str,
    mode_label: str,
    page_num: int,
    total_pages: int,
    progress: float,
    header_title: str = "",
) -> Image.Image:
    canvas = Image.new("RGB", (VIDEO_W, VIDEO_H), "#0e1416")
    draw = ImageDraw.Draw(canvas)

    # 1. Nền gradient ambient
    for y in range(0, VIDEO_H, 6):
        alpha = math.sin((y / VIDEO_H) * math.pi) * 0.15
        r = int(14 + alpha * 18)
        g = int(20 + alpha * 24)
        b = int(22 + alpha * 28)
        draw.rectangle([0, y, VIDEO_W, y + 6], fill=(r, g, b))

    # 2. Header
    font_header = get_font(20, bold=True)
    # [v3.0.1] Tiêu đề lấy từ manifest/PDF thay vì cố định tên một cuốn sách; số trang so với tổng trang tài liệu
    title = (header_title or "").strip()
    head = f"{title.upper()} · {mode_label.upper()}" if title else mode_label.upper()
    draw.text((70, 32), head[:90], fill="#cba86a", font=font_header)
    page_label = f"TRANG {page_num} / {total_pages}"
    pw = draw.textlength(page_label, font=font_header) if hasattr(draw, "textlength") else 200
    draw.text((VIDEO_W - 70 - pw, 32), page_label, fill="#8c9aa0", font=font_header)
    draw.line([(70, 68), (VIDEO_W - 70, 68)], fill="#232f35", width=1)

    # 3. Hai trang sách song song
    book_y = 86
    book_h = 750
    scale_en = book_h / img_en.height
    w_en = int(img_en.width * scale_en)
    disp_en = img_en.resize((w_en, book_h), Image.Resampling.LANCZOS)

    scale_vi = book_h / img_vi.height
    w_vi = int(img_vi.width * scale_vi)
    disp_vi = img_vi.resize((w_vi, book_h), Image.Resampling.LANCZOS)

    gap = 46
    total_w = w_en + gap + w_vi
    start_x = (VIDEO_W - total_w) // 2

    x_en = start_x
    x_vi = start_x + w_en + gap

    # Đổ bóng
    for off in range(6, 0, -2):
        draw.rectangle([x_en + off, book_y + off, x_en + w_en + off, book_y + book_h + off], fill=(3, 5, 7))
        draw.rectangle([x_vi + off, book_y + off, x_vi + w_vi + off, book_y + book_h + off], fill=(3, 5, 7))

    canvas.paste(disp_en, (x_en, book_y))
    canvas.paste(disp_vi, (x_vi, book_y))

    # Viền trang
    draw.rectangle([x_en, book_y, x_en + w_en, book_y + book_h], outline="#2d3c43", width=1)
    draw.rectangle([x_vi, book_y, x_vi + w_vi, book_y + book_h], outline="#2d3c43", width=1)

    # Tag ngôn ngữ
    font_tag = get_font(13, bold=True)
    draw.rectangle([x_en + 10, book_y + 10, x_en + 110, book_y + 34], fill="#182226", outline="#3b4d54")
    draw.text((x_en + 20, book_y + 14), "ENGLISH", fill="#8bb5c7", font=font_tag)

    draw.rectangle([x_vi + 10, book_y + 10, x_vi + 130, book_y + 34], fill="#182226", outline="#3b4d54")
    draw.text((x_vi + 20, book_y + 14), "TIẾNG VIỆT", fill="#00c3db", font=font_tag)

    # 4. Highlight Bounding Box
    pdf_h = 792.0
    pdf_w = 612.0
    if active_bbox_en:
        bx0, by0, bx1, by1 = active_bbox_en
        hl_x0 = x_en + int((bx0 / pdf_w) * w_en)
        hl_y0 = book_y + int((by0 / pdf_h) * book_h)
        hl_x1 = x_en + int((bx1 / pdf_w) * w_en)
        hl_y1 = book_y + int((by1 / pdf_h) * book_h)
        draw.rectangle([hl_x0 - 3, hl_y0 - 3, hl_x1 + 3, hl_y1 + 3], outline="#e5a93c", width=3)

    if active_bbox_vi:
        bx0, by0, bx1, by1 = active_bbox_vi
        hl_x0 = x_vi + int((bx0 / pdf_w) * w_vi)
        hl_y0 = book_y + int((by0 / pdf_h) * book_h)
        hl_x1 = x_vi + int((bx1 / pdf_w) * w_vi)
        hl_y1 = book_y + int((by1 / pdf_h) * book_h)
        draw.rectangle([hl_x0 - 3, hl_y0 - 3, hl_x1 + 3, hl_y1 + 3], outline="#00d8f0", width=3)

    # 5. Phụ đề ở đáy màn hình
    sub_y = 856
    draw.rectangle([70, sub_y, VIDEO_W - 70, VIDEO_H - 42], fill="#131b1e", outline="#25343a")

    font_sub_label = get_font(15, bold=True)
    font_sub_text = get_font(20, bold=True)

    draw.text((100, sub_y + 12), sub_title, fill="#cba86a", font=font_sub_label)
    sub_lines = wrap_text(sub_text, max_chars_per_line=95)
    for l_idx, line_str in enumerate(sub_lines):
        draw.text((100, sub_y + 38 + l_idx * 26), line_str, fill=sub_color, font=font_sub_text)

    # 6. Thanh tiến độ
    bar_w = int((VIDEO_W - 140) * progress)
    draw.rectangle([70, VIDEO_H - 32, 70 + bar_w, VIDEO_H - 28], fill="#cba86a")

    return canvas


def build_reading_video(
    src_pdf: Path,
    trn_pdf: Path,
    manifest_path: Path,
    audio_dir: Path,
    pages: Optional[List[int]],
    out_video: Path,
    mode: str = "bilingual",
) -> Path:
    """Tạo video đọc sách đạt chuẩn broadcast 25fps + 48kHz AAC."""
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    header_title = (
        (manifest.get("translation") or {}).get("title")
        or manifest.get("title")
        or ""
    )
    all_pages = [int(p) for p in manifest.get("pages", {}).keys()]
    target_pages = [p for p in pages if p in all_pages] if pages else all_pages
    target_pages.sort()

    src_doc = fitz.open(src_pdf)
    trn_doc = fitz.open(trn_pdf)
    out_video.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_p = Path(tmp_dir)
        master_wav = tmp_p / "master_audio.wav"
        concat_file = tmp_p / "concat_frames.txt"

        gap_sec = 0.22
        gap_data = np.zeros(int(24000 * gap_sec), dtype=np.float32)

        concat_lines: List[str] = []
        frame_idx = 0

        with sf.SoundFile(str(master_wav), mode="w", samplerate=24000, channels=1, subtype="PCM_16") as wav_writer:
            if mode == "mono_vi":
                total_items = sum(len(manifest["pages"].get(str(p), {}).get("vi", {}).get("segments", [])) for p in target_pages)
                cur_item = 0
                for p in target_pages:
                    pk = str(p)
                    p_info = manifest["pages"].get(pk, {})
                    vi_segs = p_info.get("vi", {}).get("segments", [])
                    if not vi_segs:
                        continue
                    img_en = render_page_image(src_doc[p - 1], target_h=1000)
                    img_vi = render_page_image(trn_doc[p - 1], target_h=1000)

                    for i, seg in enumerate(vi_segs):
                        cur_item += 1
                        seg_wav_p = audio_dir / "vi" / f"p{p:03d}_s{i:02d}.wav"
                        if not seg_wav_p.is_file():
                            continue
                        data, sr = sf.read(str(seg_wav_p), dtype="float32")
                        if data.ndim > 1:
                            data = data.mean(axis=1)
                        wav_writer.write(np.clip(data, -0.95, 0.95))
                        wav_writer.write(gap_data)
                        seg_dur = len(data) / sr + gap_sec

                        frame_img = compose_video_frame(
                            img_en=img_en,
                            img_vi=img_vi,
                            active_bbox_en=None,
                            active_bbox_vi=seg.get("bbox"),
                            sub_title=f"BẢN DỊCH TIẾNG VIỆT · ĐOẠN {i+1}/{len(vi_segs)}",
                            sub_text=seg.get("text", ""),
                            sub_color="#ffffff",
                            mode_label="Bản Dịch Tiếng Việt",
                            page_num=p,
                            total_pages=src_doc.page_count,
                            header_title=header_title,
                            progress=cur_item / total_items,
                        )
                        frame_path = tmp_p / f"f_{frame_idx:04d}.png"
                        frame_img.save(str(frame_path), "PNG")
                        concat_lines.append(f"file '{frame_path.resolve().as_posix()}'")
                        concat_lines.append(f"duration {seg_dur:.4f}")
                        frame_idx += 1
            else:
                # Bilingual Alternating: EN -> VI
                total_pairs = sum(max(len(manifest["pages"].get(str(p), {}).get("en", {}).get("segments", [])),
                                      len(manifest["pages"].get(str(p), {}).get("vi", {}).get("segments", []))) for p in target_pages)
                cur_pair = 0
                for p in target_pages:
                    pk = str(p)
                    p_info = manifest["pages"].get(pk, {})
                    vi_segs = p_info.get("vi", {}).get("segments", [])
                    en_segs = p_info.get("en", {}).get("segments", [])
                    img_en = render_page_image(src_doc[p - 1], target_h=1000)
                    img_vi = render_page_image(trn_doc[p - 1], target_h=1000)
                    num_pairs = max(len(en_segs), len(vi_segs))

                    for i in range(num_pairs):
                        cur_pair += 1
                        if i < len(en_segs):
                            seg_en = en_segs[i]
                            f_en = audio_dir / "en" / f"p{p:03d}_s{i:02d}.wav"
                            if f_en.is_file():
                                d_en, sr_en = sf.read(str(f_en), dtype="float32")
                                if d_en.ndim > 1:
                                    d_en = d_en.mean(axis=1)
                                wav_writer.write(np.clip(d_en, -0.95, 0.95))
                                wav_writer.write(gap_data)
                                dur_en = len(d_en) / sr_en + gap_sec

                                frame_en = compose_video_frame(
                                    img_en=img_en,
                                    img_vi=img_vi,
                                    active_bbox_en=seg_en.get("bbox"),
                                    active_bbox_vi=None,
                                    sub_title=f"BẢN GỐC TIẾNG ANH · ĐOẠN {i+1}/{num_pairs}",
                                    sub_text=seg_en.get("text", ""),
                                    sub_color="#e5a93c",
                                    mode_label="Đọc Song Ngữ (English → Tiếng Việt)",
                                    page_num=p,
                                    total_pages=src_doc.page_count,
                            header_title=header_title,
                                    progress=(cur_pair - 0.5) / total_pairs,
                                )
                                fp_en = tmp_p / f"f_{frame_idx:04d}.png"
                                frame_en.save(str(fp_en), "PNG")
                                concat_lines.append(f"file '{fp_en.resolve().as_posix()}'")
                                concat_lines.append(f"duration {dur_en:.4f}")
                                frame_idx += 1

                        if i < len(vi_segs):
                            seg_vi = vi_segs[i]
                            f_vi = audio_dir / "vi" / f"p{p:03d}_s{i:02d}.wav"
                            if f_vi.is_file():
                                d_vi, sr_vi = sf.read(str(f_vi), dtype="float32")
                                if d_vi.ndim > 1:
                                    d_vi = d_vi.mean(axis=1)
                                wav_writer.write(np.clip(d_vi, -0.95, 0.95))
                                wav_writer.write(gap_data)
                                dur_vi = len(d_vi) / sr_vi + gap_sec

                                frame_vi = compose_video_frame(
                                    img_en=img_en,
                                    img_vi=img_vi,
                                    active_bbox_en=None,
                                    active_bbox_vi=seg_vi.get("bbox"),
                                    sub_title=f"BẢN DỊCH TIẾNG VIỆT · ĐOẠN {i+1}/{num_pairs}",
                                    sub_text=seg_vi.get("text", ""),
                                    sub_color="#ffffff",
                                    mode_label="Đọc Song Ngữ (English → Tiếng Việt)",
                                    page_num=p,
                                    total_pages=src_doc.page_count,
                            header_title=header_title,
                                    progress=cur_pair / total_pairs,
                                )
                                fp_vi = tmp_p / f"f_{frame_idx:04d}.png"
                                frame_vi.save(str(fp_vi), "PNG")
                                concat_lines.append(f"file '{fp_vi.resolve().as_posix()}'")
                                concat_lines.append(f"duration {dur_vi:.4f}")
                                frame_idx += 1

        if concat_lines:
            concat_lines.append(concat_lines[-2])
        concat_file.write_text("\n".join(concat_lines), encoding="utf-8")

        # Encode 1 pass chất lượng cao broadcast 25fps + 48kHz AAC
        cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0", "-i", str(concat_file),
            "-i", str(master_wav),
            "-r", "25",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast", "-crf", "22",
            "-g", "50", "-keyint_min", "25",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-movflags", "+faststart",
            "-shortest",
            str(out_video)
        ]
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"FFmpeg failed with exit code {res.returncode}: {res.stderr}")

    src_doc.close()
    trn_doc.close()
    return out_video


def main():
    parser = argparse.ArgumentParser(description="Tạo Video Đọc Sách Song Ngữ 1080p Broadcast Standard")
    parser.add_argument("--source", required=True, type=Path, help="Đường dẫn PDF gốc tiếng Anh")
    parser.add_argument("--trans", required=True, type=Path, help="Đường dẫn PDF dịch tiếng Việt")
    parser.add_argument("--manifest", required=True, type=Path, help="Đường dẫn file manifest JSON")
    parser.add_argument("--audio-dir", type=Path, default=Path("output/bilingual-demo/audio"), help="Thư mục audio")
    parser.add_argument("--pages", type=str, default="", help="Danh sách trang (ví dụ: 1,2,4,6)")
    parser.add_argument("--mode", choices=["mono_vi", "bilingual"], default="bilingual", help="Chế độ video")
    parser.add_argument("--out", required=True, type=Path, help="Đường dẫn tệp MP4 xuất bản")

    args = parser.parse_args()
    page_list = [int(p.strip()) for p in args.pages.split(",") if p.strip()] if args.pages else None
    build_reading_video(args.source, args.trans, args.manifest, args.audio_dir, page_list, args.out, mode=args.mode)
    print(f"✅ Đã xuất bản video thành công: {args.out}")


if __name__ == "__main__":
    main()
