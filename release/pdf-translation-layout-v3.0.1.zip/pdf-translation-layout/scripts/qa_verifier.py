"""
qa_verifier.py
Cổng kiểm định chất lượng tự động 4 tầng (Automated 4-Tier QA Verification Gate).
Đo đạc chính xác: Cơ khí, Hình học, Text Layer/Tofu, và Render so sánh song song 130 DPI.
"""

import argparse
import json
import os
import pymupdf as fitz
from PIL import Image, ImageDraw, ImageFont


def run_qa_verification(source_pdf, target_pdf, report_path, bbox_log_path=None, render_dir=None, showcase_pages=None):
    doc_src = fitz.open(source_pdf)
    doc_tgt = fitz.open(target_pdf)

    showcase_pages = showcase_pages or [1, 2, 4, 6, 13, 22, 27, 52, 68, 78, 81, 82, 94, 95, 107, 142, 162, 163]
    bbox_log = {}
    if bbox_log_path and os.path.exists(bbox_log_path):
        with open(bbox_log_path, encoding="utf-8") as f:
            bbox_log = json.load(f)

    report = {
        "mechanical": {
            "source_pages": len(doc_src),
            "target_pages": len(doc_tgt),
            "page_count_match": len(doc_src) == len(doc_tgt),
            "dimensions_match": True,
            "embedded_fonts_all": True,
        },
        "geometric": {
            "total_runs_checked": 0,
            "safe_margin_violations": [],
            "image_overlap_violations": [],
            "block_collision_violations": [],
        },
        "content": {
            "replacement_char_count": 0,
            "total_characters_extracted": 0,
        },
    }

    # Extract target images bbox
    img_rects_by_page = {}
    for pno in range(len(doc_tgt)):
        p = doc_tgt[pno]
        for img in p.get_images():
            for r in p.get_image_rects(img[0]):
                img_rects_by_page.setdefault(pno + 1, []).append(r)

    for pno in range(1, len(doc_tgt) + 1):
        p_src = doc_src[pno - 1]
        p_tgt = doc_tgt[pno - 1]

        if list(p_src.rect) != list(p_tgt.rect):
            report["mechanical"]["dimensions_match"] = False

        if not p_tgt.get_fonts():
            report["mechanical"]["embedded_fonts_all"] = False

        extracted_text = p_tgt.get_text("text")
        report["content"]["replacement_char_count"] += extracted_text.count("\ufffd") + extracted_text.count("□")
        report["content"]["total_characters_extracted"] += len(extracted_text)

        runs = bbox_log.get(str(pno), [])
        block_rects = {}
        for r in runs:
            report["geometric"]["total_runs_checked"] += 1
            rx0, ry0, rx1, ry1 = r["rect"]
            r_rect = fitz.Rect(rx0, ry0, rx1, ry1)
            bid = r["block_id"]

            if bid not in block_rects:
                block_rects[bid] = fitz.Rect(rx0, ry0 + 1.0, rx1, ry1 - 2.0)
            else:
                block_rects[bid] |= fitz.Rect(rx0, ry0 + 1.0, rx1, ry1 - 2.0)

            # Safe margin check
            if rx0 < 45.0 or rx1 > 567.0 or ry0 < 45.0 or ry1 > 758.0:
                report["geometric"]["safe_margin_violations"].append({
                    "page": pno,
                    "block_id": bid,
                    "rect": r["rect"],
                    "text": r["text"][:30],
                })

            # Image overlap check
            if pno in img_rects_by_page:
                for img_r in img_rects_by_page[pno]:
                    inter = r_rect & img_r
                    if not inter.is_empty and inter.width > 2.0 and inter.height > 2.0:
                        report["geometric"]["image_overlap_violations"].append({
                            "page": pno,
                            "block_id": bid,
                            "rect": r["rect"],
                            "image_rect": [round(v, 2) for v in img_r],
                        })

        # Block collision check
        bids = list(block_rects.keys())
        for i in range(len(bids)):
            for j in range(i + 1, len(bids)):
                b1, b2 = bids[i], bids[j]
                inter = block_rects[b1] & block_rects[b2]
                if not inter.is_empty and inter.width > 1.5 and inter.height > 1.5:
                    report["geometric"]["block_collision_violations"].append({
                        "page": pno,
                        "block_1": b1,
                        "block_2": b2,
                        "intersection": [round(v, 2) for v in inter],
                    })

    # Render showcase side-by-side images
    if render_dir:
        os.makedirs(render_dir, exist_ok=True)
        for pno in showcase_pages:
            if pno > len(doc_tgt):
                continue
            p_s = doc_src[pno - 1]
            p_t = doc_tgt[pno - 1]
            pix_s = p_s.get_pixmap(dpi=130)
            pix_t = p_t.get_pixmap(dpi=130)

            img_l = Image.frombytes("RGB", [pix_s.width, pix_s.height], pix_s.samples)
            img_r = Image.frombytes("RGB", [pix_t.width, pix_t.height], pix_t.samples)

            hdr_h = 44
            gap = 16
            cw = img_l.width + img_r.width + gap * 3
            ch = max(img_l.height, img_r.height) + hdr_h + gap
            canvas = Image.new("RGB", (cw, ch), (236, 239, 241))
            draw = ImageDraw.Draw(canvas)
            font = ImageFont.load_default()

            draw.text((gap + 8, 12), f"Trang {pno:03d} — Bản gốc (Source)", fill=(42, 46, 48), font=font)
            draw.text((gap * 2 + img_l.width + 8, 12), f"Trang {pno:03d} — Bản dịch (Translated)", fill=(0, 129, 150), font=font)

            canvas.paste(img_l, (gap, hdr_h))
            canvas.paste(img_r, (gap * 2 + img_l.width, hdr_h))
            draw.rectangle([gap - 1, hdr_h - 1, gap + img_l.width, hdr_h + img_l.height], outline=(180, 186, 190), width=1)
            draw.rectangle([gap * 2 + img_l.width - 1, hdr_h - 1, gap * 2 + img_l.width + img_r.width, hdr_h + img_r.height], outline=(180, 186, 190), width=1)

            canvas.save(os.path.join(render_dir, f"page_{pno:03d}_compare.png"), optimize=True)

    doc_src.close()
    doc_tgt.close()

    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print("\n=== KẾT QUẢ KIỂM ĐỊNH QA 4 TẦNG ===")
    print("Khớp số trang:", report["mechanical"]["page_count_match"], f"({report['mechanical']['target_pages']} trang)")
    print("Khớp kích thước:", report["mechanical"]["dimensions_match"])
    print("Tổng số Text Runs kiểm tra:", report["geometric"]["total_runs_checked"])
    print("Vi phạm lề an toàn:", len(report["geometric"]["safe_margin_violations"]))
    print("Vi phạm đè lên ảnh:", len(report["geometric"]["image_overlap_violations"]))
    print("Vi phạm va chạm khối:", len(report["geometric"]["block_collision_violations"]))
    print("Ký tự lỗi / Tofu:", report["content"]["replacement_char_count"])
    print("Tổng số ký tự trích xuất sạch:", report["content"]["total_characters_extracted"])
    if report["geometric"]["total_runs_checked"] == 0:
        print("[CẢNH BÁO] Tầng 2 (Hình học) CHƯA được kiểm: không tìm thấy layout log. "
              "Chạy lại translate-mono (tạo *_layout_log.json) hoặc truyền --layout-log.")


def main():
    parser = argparse.ArgumentParser(description="Kiểm định tự động 4 tầng chất lượng PDF xuất xưởng.")
    parser.add_argument("--source", "-s", required=True, help="File PDF nguồn")
    parser.add_argument("--target", "-t", required=True, help="File PDF kết xuất")
    parser.add_argument("--report", "-r", default="data/qa_report.json", help="File JSON báo cáo QA")
    parser.add_argument("--layout-log", "-l", default="data/layout_bboxes_log.json", help="File JSON layout log")
    parser.add_argument("--renders", default="output/qa_renders", help="Thư mục xuất ảnh so sánh song song")
    args = parser.parse_args()

    run_qa_verification(args.source, args.target, args.report, args.layout_log, args.renders)


if __name__ == "__main__":
    main()
