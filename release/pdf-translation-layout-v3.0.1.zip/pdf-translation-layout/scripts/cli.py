#!/usr/bin/env python3
"""
cli.py — Giao diện Điều Khiển Trung Tâm (Universal CLI Entrypoint) cho pdf-translation-layout v3.0.
Cung cấp các lệnh subcommands trực quan:
  1. inspect        : Kiểm kê cơ khí, font chữ, ảnh, links và text blocks của tài liệu gốc.
  2. translate-mono : Dàn trang PDF tiếng Việt đơn ngữ bảo tồn 100% Vector Text Layer.
  3. bilingual      : Xuất bản 2 bố cục song ngữ chuẩn xuất bản (Facing Pages & Interleaved Flow).
  4. voice          : Phòng thu giọng đọc VieNeu-TTS v3 (Tổng hợp, Nhân bản giọng nói 3-8s).
  5. video          : Xuất bản video đọc sách 1080p broadcast 25fps + 48kHz AAC (mono & song ngữ).
  6. qa             : Cổng kiểm định chất lượng 4 tầng tự động (Mechanical, Geometric, Content, Visual).

Ví dụ:
  python scripts/cli.py inspect --source doc.pdf --out-dir data/
  python scripts/cli.py translate-mono --source doc.pdf --trans trans.json --out out.pdf
  python scripts/cli.py bilingual --source doc.pdf --trans out.pdf --mode facing --out-book facing_book.pdf
  python scripts/cli.py voice synth --text "Xin chào" --lang vi --voice "Đức Trí" --out hello.wav
  python scripts/cli.py video --source doc.pdf --trans out.pdf --manifest mf.json --mode bilingual --out video.mp4
  python scripts/cli.py qa --source doc.pdf --target out.pdf --report qa_report.json
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent


def cmd_inspect(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "inventory_extractor.py"), "--input", str(args.source), "--output", str(args.out_dir)]
    return subprocess.run(cmd).returncode


def cmd_translate_mono(args: argparse.Namespace) -> int:
    cmd = [
        sys.executable, str(SCRIPTS_DIR / "adaptive_pdf_engine.py"),
        "--source", str(args.source),
        "--trans", str(args.trans),
        "--output", str(args.out),
        "--fonts", str(args.fonts),
    ]
    if args.pages:
        cmd.extend(["--pages", str(args.pages)])
    return subprocess.run(cmd).returncode


def cmd_bilingual(args: argparse.Namespace) -> int:
    if args.mode in ("facing", "all"):
        out_book = args.out_book or Path("output/facing_book.pdf")
        out_sheet = args.out_sheet or Path("output/facing_sheet.pdf")
        cmd_f = [
            sys.executable, str(SCRIPTS_DIR / "bilingual_layouts.py"), "facing",
            "--source", str(args.source),
            "--trans", str(args.trans),
            "--out-book", str(out_book),
            "--out-sheet", str(out_sheet),
        ]
        if args.pages:
            cmd_f.extend(["--pages", str(args.pages)])
        code = subprocess.run(cmd_f).returncode
        if code != 0 or args.mode == "facing":
            return code

    if args.mode in ("interleaved", "all"):
        out_int = args.out_interleaved or Path("output/interleaved.pdf")
        cmd_i = [
            sys.executable, str(SCRIPTS_DIR / "bilingual_layouts.py"), "interleaved",
            "--source", str(args.source),
            "--trans", str(args.trans),
            "--out", str(out_int),
        ]
        if args.pages:
            cmd_i.extend(["--pages", str(args.pages)])
        return subprocess.run(cmd_i).returncode
    return 0


def cmd_voice(args: argparse.Namespace) -> int:
    voice_script = SCRIPTS_DIR / "voice_studio.py"
    cmd = [sys.executable, str(voice_script)] + args.voice_args
    return subprocess.run(cmd).returncode


def cmd_video(args: argparse.Namespace) -> int:
    cmd = [
        sys.executable, str(SCRIPTS_DIR / "reading_video_engine.py"),
        "--source", str(args.source),
        "--trans", str(args.trans),
        "--manifest", str(args.manifest),
        "--mode", str(args.mode),
        "--out", str(args.out),
    ]
    if args.audio_dir:
        cmd.extend(["--audio-dir", str(args.audio_dir)])
    if args.pages:
        cmd.extend(["--pages", str(args.pages)])
    return subprocess.run(cmd).returncode


def cmd_qa(args: argparse.Namespace) -> int:
    cmd = [
        sys.executable, str(SCRIPTS_DIR / "qa_verifier.py"),
        "--source", str(args.source),
        "--target", str(args.target),
        "--report", str(args.report),
    ]
    # [v3.0.1] Tự dò layout log do translate-mono sinh ra cạnh file đích
    layout_log = args.layout_log or args.target.with_name(args.target.stem + "_layout_log.json")
    if Path(layout_log).exists():
        cmd.extend(["--layout-log", str(layout_log)])
    return subprocess.run(cmd).returncode


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="pdf-translation-layout",
        description="Universal Adaptive Vector PDF Translation & Media Publishing Ecosystem v3.0",
    )
    sub = parser.add_subparsers(dest="command", required=True, help="Các lệnh chức năng")

    # 1. inspect
    p_insp = sub.add_parser("inspect", help="Kiểm kê thông số tài liệu nguồn (trang, fonts, ảnh, links, text)")
    p_insp.add_argument("--source", required=True, type=Path, help="PDF nguồn")
    p_insp.add_argument("--out-dir", type=Path, default=Path("data"), help="Thư mục xuất JSON kết quả")
    p_insp.set_defaults(func=cmd_inspect)

    # 2. translate-mono
    p_mono = sub.add_parser("translate-mono", help="Dàn trang PDF đơn ngữ tiếng Việt bảo tồn 100%% Vector Text Layer")
    p_mono.add_argument("--source", required=True, type=Path, help="PDF gốc")
    p_mono.add_argument("--trans", required=True, type=Path, help="Tệp JSON bản dịch")
    p_mono.add_argument("--out", required=True, type=Path, help="PDF xuất bản")
    p_mono.add_argument("--pages", type=str, default="", help="Phạm vi trang (vd: 1-10)")
    p_mono.add_argument("--fonts", type=Path, default=SCRIPTS_DIR.parent / "assets" / "fonts", help="Thư mục font TTF (mặc định: assets/fonts)")
    p_mono.set_defaults(func=cmd_translate_mono)

    # 3. bilingual
    p_bi = sub.add_parser("bilingual", help="Xuất bản 2 bố cục song ngữ (Facing Book & Interleaved Flow)")
    p_bi.add_argument("--source", required=True, type=Path, help="PDF gốc tiếng Anh")
    p_bi.add_argument("--trans", required=True, type=Path, help="PDF dịch tiếng Việt")
    p_bi.add_argument("--mode", choices=["facing", "interleaved", "all"], default="all", help="Chế độ layout")
    p_bi.add_argument("--pages", type=str, default="", help="Phạm vi trang (vd: 1,2,4-6)")
    p_bi.add_argument("--out-book", type=Path, default=None, help="Tệp PDF Facing Book")
    p_bi.add_argument("--out-sheet", type=Path, default=None, help="Tệp PDF Facing Sheet 2-up")
    p_bi.add_argument("--out-interleaved", type=Path, default=None, help="Tệp PDF Interleaved")
    p_bi.set_defaults(func=cmd_bilingual)

    # 4. voice
    p_voice = sub.add_parser("voice", help="Voice Studio: VieNeu-TTS v3, nhân bản giọng nói và tổng hợp audio")
    p_voice.add_argument("voice_args", nargs=argparse.REMAINDER, help="Các tham số chuyển tiếp cho voice_studio.py")
    p_voice.set_defaults(func=cmd_voice)

    # 5. video
    p_vid = sub.add_parser("video", help="Xuất bản Video đọc sách 1080p chuẩn phát sóng broadcast 25fps + 48kHz AAC")
    p_vid.add_argument("--source", required=True, type=Path, help="PDF gốc")
    p_vid.add_argument("--trans", required=True, type=Path, help="PDF dịch")
    p_vid.add_argument("--manifest", required=True, type=Path, help="File bilingual_manifest.json")
    p_vid.add_argument("--audio-dir", type=Path, default=None, help="Thư mục chứa các tệp audio wav")
    p_vid.add_argument("--pages", type=str, default="", help="Danh sách trang (vd: 1,2,4,6)")
    p_vid.add_argument("--mode", choices=["mono_vi", "bilingual"], default="bilingual", help="Chế độ đọc")
    p_vid.add_argument("--out", required=True, type=Path, help="Tệp MP4 xuất bản")
    p_vid.set_defaults(func=cmd_video)

    # 6. qa
    p_qa = sub.add_parser("qa", help="Cổng kiểm định chất lượng 4 tầng tự động (Mechanical, Geo, Content, Visual)")
    p_qa.add_argument("--source", required=True, type=Path, help="PDF nguồn")
    p_qa.add_argument("--target", required=True, type=Path, help="PDF xuất bản cần kiểm định")
    p_qa.add_argument("--report", type=Path, default=Path("data/qa_report.json"), help="File JSON báo cáo QA")
    p_qa.add_argument("--layout-log", type=Path, default=None, help="Layout log JSON (mặc định: <target>_layout_log.json)")
    p_qa.set_defaults(func=cmd_qa)

    args = parser.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
