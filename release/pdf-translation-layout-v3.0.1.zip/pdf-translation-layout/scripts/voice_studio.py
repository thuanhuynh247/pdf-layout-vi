#!/usr/bin/env python3
"""
voice_studio.py — Phòng thu giọng đọc song ngữ EN/VI dựa trên VieNeu-TTS (https://www.vieneu.io/).

Giọng đọc "đóng gói sẵn" (ready-made voices) giống skill huong-nghiep-short-video-engine:
  • VI: 10 preset VieNeu v3nano (Minh Quân, Đức Trí, Anh Khôi, Trúc Ly, Mỹ Duyên, Mai Anh, ...).
  • EN: preset VieNeu "Adam" (đo ASR-match 0.97 trên câu mẫu) + giọng bản ngữ edge-tts (Andrew/Ava) để lựa chọn.
  • Clone: tạo hồ sơ giọng mới từ mẫu 3–8 giây (`clone`), lưu vào voices.json để dùng lại.

Tầng engine (theo thứ tự `auto`): cloud api.vieneu.io (nếu có VIENEU_API_KEY) → VieNeu local v3nano → edge-tts.
Lưu ý thực chứng: VieNeu v3turbo cần nhiều RAM; trên máy ~3 GB RAM trống không nạp được → mặc định v3nano.

CLI:
  python voice_studio.py list
  python voice_studio.py synth --lang en --voice Adam --text "Hello" --out a.wav
  python voice_studio.py clone --name "Thuận EN" --lang en --ref my_voice.wav --ref-text "transcript of sample"
  python voice_studio.py synth-segments --segments segments_vi.json --lang vi --voice "Đức Trí" --out-dir audio/vi
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import requests
import soundfile as sf

SKILL_DIR = Path(__file__).resolve().parent.parent
VOICES_JSON = SKILL_DIR / "voices" / "voices.json"
SAMPLE_RATE = 24000  # 24kHz chuẩn của VieNeu v3nano & edge-tts, tiết kiệm 100% RAM resample
VIENEU_API = os.environ.get("VIENEU_API_BASE", "https://api.vieneu.io/api/v1").rstrip("/")

DEFAULT_VOICES: Dict[str, dict] = {
    # --- Tiếng Việt: preset VieNeu v3nano ---
    "Đức Trí": {"lang": "vi", "engine": "vieneu", "preset": "Đức Trí", "desc": "Nam · Bắc · đọc truyện (mặc định VI)"},
    "Mỹ Duyên": {"lang": "vi", "engine": "vieneu", "preset": "Mỹ Duyên", "desc": "Nữ · Bắc · đọc truyện"},
    "Anh Khôi": {"lang": "vi", "engine": "vieneu", "preset": "Anh Khôi", "desc": "Nam · Bắc · kể chuyện"},
    "Minh Quân": {"lang": "vi", "engine": "vieneu", "preset": "Minh Quân", "desc": "Nam · Bắc · tự nhiên"},
    "Trúc Ly": {"lang": "vi", "engine": "vieneu", "preset": "Trúc Ly", "desc": "Nữ · Bắc · tự nhiên"},
    "Mai Anh": {"lang": "vi", "engine": "vieneu", "preset": "Mai Anh", "desc": "Nữ · Bắc · tin tức"},
    "Ái Hân": {"lang": "vi", "engine": "vieneu", "preset": "Ái Hân", "desc": "Nữ · Nam · tin tức"},
    # --- Tiếng Anh ---
    "Adam": {"lang": "en", "engine": "vieneu", "preset": "Adam", "desc": "VieNeu preset · nam · đọc tiếng Anh (mặc định EN)"},
    "Andrew (native)": {"lang": "en", "engine": "edge", "preset": "en-US-AndrewNeural", "desc": "Giọng bản ngữ Mỹ · nam (edge-tts)"},
    "Ava (native)": {"lang": "en", "engine": "edge", "preset": "en-US-AvaNeural", "desc": "Giọng bản ngữ Mỹ · nữ (edge-tts)"},
}
DEFAULT_BY_LANG = {"vi": "Đức Trí", "en": "Adam"}

_ENGINE = {}


def load_voices() -> Dict[str, dict]:
    voices = dict(DEFAULT_VOICES)
    if VOICES_JSON.is_file():
        voices.update(json.loads(VOICES_JSON.read_text(encoding="utf-8")).get("custom", {}))
    return voices


def save_custom(name: str, profile: dict) -> None:
    VOICES_JSON.parent.mkdir(parents=True, exist_ok=True)
    data = json.loads(VOICES_JSON.read_text(encoding="utf-8")) if VOICES_JSON.is_file() else {"custom": {}}
    data["custom"][name] = profile
    VOICES_JSON.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get_vieneu(mode: str = "v3nano"):
    if mode not in _ENGINE:
        from vieneu import Vieneu
        t = time.time()
        _ENGINE[mode] = Vieneu(mode=mode)
        print(f"[voice] nạp VieNeu {mode} trong {time.time() - t:.1f}s", file=sys.stderr)
    return _ENGINE[mode]


def _to_48k_mono(src: Path, dst: Path) -> Path:
    if src.resolve() == dst.resolve():
        return dst
    data, sr = sf.read(str(src), dtype="float32")
    if data.ndim > 1:
        data = data.mean(axis=1)
    peak = float(np.max(np.abs(data))) or 1.0
    data = data * min(1.0, 0.90 / peak)
    sf.write(str(dst), data, sr, subtype="PCM_16")
    return dst


def _synth_vieneu_local(text: str, profile: dict, out: Path, mode: str) -> Path:
    tts = get_vieneu(mode)
    if profile.get("ref_audio"):
        wav = tts.infer(text, ref_audio=profile["ref_audio"], ref_text=profile.get("ref_text"))
    else:
        wav = tts.infer(text, voice=profile["preset"])
    tmp = out.with_suffix(".raw.wav")
    tts.save(wav, str(tmp))
    _to_48k_mono(tmp, out)
    tmp.unlink(missing_ok=True)
    return out


def _synth_vieneu_cloud(text: str, profile: dict, out: Path) -> Path:
    key = os.environ.get("VIENEU_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thiếu VIENEU_API_KEY")
    r = requests.post(
        f"{VIENEU_API}/audio/speech",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"model": "vieneu-turbo", "input": text, "voice": profile.get("cloud_voice") or profile.get("preset"), "response_format": "wav"},
        timeout=120,
    )
    r.raise_for_status()
    tmp = out.with_suffix(".cloud.wav")
    tmp.write_bytes(r.content)
    _to_48k_mono(tmp, out)
    tmp.unlink(missing_ok=True)
    return out


def _synth_edge(text: str, voice: str, out: Path, rate: str = "+0%") -> Path:
    import edge_tts
    tmp = out.with_suffix(".edge.mp3")
    for attempt in range(3):
        try:
            asyncio.run(edge_tts.Communicate(text, voice, rate=rate).save(str(tmp)))
            if tmp.is_file() and tmp.stat().st_size > 100:
                break
        except Exception as e:
            if attempt == 2:
                # Fallback sang VieNeu local với giọng Adam
                print(f"[voice] edge-tts lỗi ({e}) -> Fallback sang VieNeu local (Adam)", file=sys.stderr)
                return _synth_vieneu_local(text, {"preset": "Adam"}, out, "v3nano")
            time.sleep(1.2)
    _to_48k_mono(tmp, out)
    tmp.unlink(missing_ok=True)
    return out


def synth(text: str, voice_name: str, out: Path, engine: str = "auto", mode: str = "v3nano") -> str:
    """Tổng hợp 1 đoạn → WAV 48 kHz mono. Trả về tên engine đã dùng."""
    voices = load_voices()
    if voice_name not in voices:
        raise SystemExit(f"Không có giọng '{voice_name}'. Dùng `list` để xem danh sách.")
    p = voices[voice_name]
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if p["engine"] == "edge":
        _synth_edge(text, p["preset"], out)
        return "edge-tts"
    if engine in ("auto", "cloud") and os.environ.get("VIENEU_API_KEY") and not p.get("ref_audio"):
        try:
            _synth_vieneu_cloud(text, p, out)
            return "vieneu-cloud"
        except Exception as e:  # noqa: BLE001
            if engine == "cloud":
                raise
            print(f"[voice] cloud lỗi ({e}) → chuyển local", file=sys.stderr)
    _synth_vieneu_local(text, p, out, mode)
    return f"vieneu-local-{mode}"


def concat_wavs(paths: List[Path], out: Path, gap_s: float = 0.18) -> float:
    """Ghép các file WAV theo dạng Stream không tốn RAM, ghi thẳng xuống đĩa."""
    if not paths:
        return 0.0
    first_info = sf.info(str(paths[0]))
    base_sr = first_info.samplerate
    gap_samples = int(base_sr * gap_s)
    gap_data = np.zeros(gap_samples, dtype=np.float32)

    total_frames = 0
    with sf.SoundFile(str(out), mode="w", samplerate=base_sr, channels=1, subtype="PCM_16") as writer:
        for i, p in enumerate(paths):
            data, sr = sf.read(str(p), dtype="float32")
            if data.ndim > 1:
                data = data.mean(axis=1)
            # Clip an toàn
            data = np.clip(data, -0.95, 0.95)
            writer.write(data)
            total_frames += len(data)
            if i < len(paths) - 1:
                writer.write(gap_data)
                total_frames += gap_samples
            del data
            import gc; gc.collect()
    return total_frames / base_sr


def synth_segments(segments_json: Path, lang: str, voice: str, out_dir: Path, engine: str = "auto", force: bool = False) -> dict:
    """Tổng hợp audio cho từng segment của từng trang; có cache (bỏ qua file đã có)."""
    sys.path.insert(0, str(Path(__file__).parent))
    from page_segments import split_sentences

    data = json.loads(Path(segments_json).read_text(encoding="utf-8"))
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"lang": lang, "voice": voice, "sample_rate": SAMPLE_RATE, "pages": {}}
    t0 = time.time()
    for pkey, page in data.items():
        items = []
        for i, seg in enumerate(page["segments"]):
            wav = out_dir / f"p{int(pkey):03d}_s{i:02d}.wav"
            if force or not wav.is_file():
                parts = []
                with tempfile.TemporaryDirectory() as td:
                    for j, sent in enumerate(split_sentences(seg["speech"])):
                        pp = Path(td) / f"{j:02d}.wav"
                        used = synth(sent, voice, pp, engine=engine)
                        parts.append(pp)
                    concat_wavs(parts, wav)
            dur = sf.info(str(wav)).duration
            items.append({"index": i, "file": wav.name, "duration": round(dur, 3), "bbox": seg["bbox"]})
            print(f"[voice] {lang} p{pkey} s{i:02d} {dur:5.1f}s  (tổng {time.time() - t0:5.0f}s)", flush=True)
        page_wav = out_dir / f"page_{int(pkey):03d}.wav"
        page_dur = concat_wavs([out_dir / it["file"] for it in items], page_wav, gap_s=0.35) if items else 0.0
        manifest["pages"][pkey] = {"segments": items, "page_file": page_wav.name, "duration": round(page_dur, 3)}
        import gc; gc.collect()
    (out_dir / "audio_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    return manifest


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    s = sub.add_parser("synth")
    s.add_argument("--lang", choices=["en", "vi"], required=True)
    s.add_argument("--voice", default="")
    s.add_argument("--text", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--engine", default="auto", choices=["auto", "local", "cloud"])
    c = sub.add_parser("clone", help="Tạo hồ sơ giọng nhân bản từ mẫu 3–8 giây")
    c.add_argument("--name", required=True)
    c.add_argument("--lang", choices=["en", "vi"], required=True)
    c.add_argument("--ref", required=True, help="WAV/MP3 mẫu giọng 3–8s, sạch nhiễu")
    c.add_argument("--ref-text", default="", help="Lời thoại đúng của file mẫu (tăng độ giống)")
    g = sub.add_parser("synth-segments")
    g.add_argument("--segments", required=True)
    g.add_argument("--lang", choices=["en", "vi"], required=True)
    g.add_argument("--voice", default="")
    g.add_argument("--out-dir", required=True)
    g.add_argument("--engine", default="auto", choices=["auto", "local", "cloud"])
    g.add_argument("--force", action="store_true")
    a = ap.parse_args()

    if a.cmd == "list":
        for name, p in load_voices().items():
            mark = " (mặc định)" if DEFAULT_BY_LANG.get(p["lang"]) == name else ""
            print(f"  [{p['lang']}] {name:18s} {p['engine']:7s} {p.get('desc', '')}{mark}")
        return 0
    if a.cmd == "synth":
        used = synth(a.text, a.voice or DEFAULT_BY_LANG[a.lang], Path(a.out), engine=a.engine)
        print(f"[voice OK] {a.out} ({used})")
        return 0
    if a.cmd == "clone":
        ref = Path(a.ref).resolve()
        if not ref.is_file():
            raise SystemExit(f"Không thấy file mẫu: {ref}")
        dur = sf.info(str(ref)).duration
        if not 2.5 <= dur <= 15:
            print(f"[cảnh báo] mẫu dài {dur:.1f}s — khuyến nghị 3–8s", file=sys.stderr)
        dst = VOICES_JSON.parent / "refs" / f"{a.name.replace(' ', '_')}{ref.suffix}"
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(ref.read_bytes())
        save_custom(a.name, {"lang": a.lang, "engine": "vieneu", "ref_audio": str(dst), "ref_text": a.ref_text, "desc": f"Giọng nhân bản từ {ref.name}"})
        print(f"[voice OK] Đã tạo giọng nhân bản '{a.name}' ({a.lang}) → {VOICES_JSON}")
        return 0
    if a.cmd == "synth-segments":
        m = synth_segments(Path(a.segments), a.lang, a.voice or DEFAULT_BY_LANG[a.lang], Path(a.out_dir), engine=a.engine, force=a.force)
        total = sum(p["duration"] for p in m["pages"].values())
        print(f"[voice OK] {len(m['pages'])} trang, {total / 60:.1f} phút audio → {a.out_dir}")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
