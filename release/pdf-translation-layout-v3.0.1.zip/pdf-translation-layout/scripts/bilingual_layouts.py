#!/usr/bin/env python3
"""
bilingual_layouts.py — Tạo 2 layout song song ngữ (bilingual layouts) từ PDF gốc và PDF dịch:

Layout 1: Đối trang (Facing Pages / Side-by-Side Spread)
  - Hoạt động chuẩn xác với sách 3D Nocturne hoặc trình đọc 2 trang.
  - Cấu trúc trang: Bìa -> [Trang N Gốc (EN) bên trái | Trang N Dịch (VI) bên phải].
  - Bảo tồn 100% Vector Text Layer, links và hình ảnh thông qua PyMuPDF `show_pdf_page` / `insert_pdf`.
  - Có 2 phiên bản kết xuất:
      a) `facing_book.pdf`: Số trang gấp đôi (xen kẽ EN/VI trang đơn), mở 2-up sẽ luôn thấy trái EN phải VI.
      b) `facing_sheet.pdf`: Khổ đôi (2-up sheet) ghép 2 trang vào 1 trang rộng (W = 2 * W0), in ấn hoặc xem trên màn hình ngang.

Layout 2: Xen đoạn (Interleaved Paragraphs)
  - Trong cùng 1 trang, mỗi đoạn văn bản gốc (EN) được đặt cạnh/trên đoạn dịch (VI).
  - Bản dịch tiếng Việt được tô màu nhận diện (mặc định teal `#0a7a8c` hoặc brand #2a2e30) và font Plus Jakarta Sans.
  - Sử dụng PyMuPDF Story/Flowable để căn chỉnh độ nở văn bản mượt mà, không tràn lề.

CLI:
  python bilingual_layouts.py facing --source en.pdf --trans vi.pdf --pages 1-6 --out-book facing_book.pdf --out-sheet facing_sheet.pdf
  python bilingual_layouts.py interleaved --source en.pdf --trans vi.pdf --pages 1-6 --out interleaved.pdf
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

import fitz  # PyMuPDF


def parse_page_range(spec: str, total_pages: int) -> List[int]:
    """Phân giải chuỗi trang như '1,2,4-6' thành danh sách [1, 2, 4, 5, 6] (1-based)."""
    if not spec or spec.lower() == "all":
        return list(range(1, total_pages + 1))
    pages: List[int] = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            pages.extend(range(int(start), int(end) + 1))
        elif part:
            pages.append(int(part))
    return [p for p in pages if 1 <= p <= total_pages]


def build_facing_book_pdf(
    source_pdf: Path,
    trans_pdf: Path,
    out_book: Path,
    pages: Optional[List[int]] = None,
    include_cover: bool = True,
) -> Path:
    """Tạo PDF đối trang (Facing Book PDF):
    Trang 1: Bìa (nếu có)
    Trang 2: Trang 1 EN (Trang bên trái khi mở 2-up)
    Trang 3: Trang 1 VI (Trang bên phải khi mở 2-up)
    ...
    Hoàn toàn giữ nguyên vector layer, font, link và chất lượng gốc.
    """
    src_doc = fitz.open(source_pdf)
    trn_doc = fitz.open(trans_pdf)
    out_doc = fitz.open()

    page_nums = pages or list(range(1, min(src_doc.page_count, trn_doc.page_count) + 1))

    # Nếu trang 1 là bìa và người dùng muốn giữ bìa đơn đầu sách
    start_idx = 0
    if include_cover and 1 in page_nums:
        # Chèn trang bìa đơn
        out_doc.insert_pdf(trn_doc, from_page=0, to_page=0)
        start_idx = 1

    for p in page_nums[start_idx:]:
        idx = p - 1
        if idx < src_doc.page_count and idx < trn_doc.page_count:
            # Chèn trang EN (trái)
            out_doc.insert_pdf(src_doc, from_page=idx, to_page=idx)
            # Chèn trang VI (phải)
            out_doc.insert_pdf(trn_doc, from_page=idx, to_page=idx)

    out_book.parent.mkdir(parents=True, exist_ok=True)
    out_doc.save(str(out_book), garbage=1, deflate=True)
    out_doc.close()
    src_doc.close()
    trn_doc.close()
    return out_book


def build_facing_sheet_pdf(
    source_pdf: Path,
    trans_pdf: Path,
    out_sheet: Path,
    pages: Optional[List[int]] = None,
) -> Path:
    """Tạo PDF bảng đối trang 2-up (W = W_en + W_vi) trên cùng 1 trang lớn:
    Phía trái: Bản gốc tiếng Anh
    Phía phải: Bản dịch tiếng Việt
    Giữ 100% Vector Text Layer bằng `show_pdf_page`.
    """
    src_doc = fitz.open(source_pdf)
    trn_doc = fitz.open(trans_pdf)
    out_doc = fitz.open()

    page_nums = pages or list(range(1, min(src_doc.page_count, trn_doc.page_count) + 1))

    for p in page_nums:
        idx = p - 1
        if idx >= src_doc.page_count or idx >= trn_doc.page_count:
            continue
        p_src = src_doc[idx]
        p_trn = trn_doc[idx]

        r_src = p_src.rect
        r_trn = p_trn.rect

        new_w = r_src.width + r_trn.width
        new_h = max(r_src.height, r_trn.height)

        new_page = out_doc.new_page(width=new_w, height=new_h)

        # Đặt trang EN ở nửa trái
        target_src_rect = fitz.Rect(0, 0, r_src.width, r_src.height)
        new_page.show_pdf_page(target_src_rect, src_doc, idx)

        # Đặt trang VI ở nửa phải
        target_trn_rect = fitz.Rect(r_src.width, 0, new_w, r_trn.height)
        new_page.show_pdf_page(target_trn_rect, trn_doc, idx)

        # Vẽ đường phân cách mảnh giữa 2 trang
        shape = new_page.new_shape()
        shape.draw_line(fitz.Point(r_src.width, 0), fitz.Point(r_src.width, new_h))
        shape.finish(color=(0.85, 0.85, 0.85), width=0.75)
        shape.commit()

    out_sheet.parent.mkdir(parents=True, exist_ok=True)
    out_doc.save(str(out_sheet), garbage=1, deflate=True)
    out_doc.close()
    src_doc.close()
    trn_doc.close()
    return out_sheet


FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _fit_textbox(page, x0, y, x1, max_y, text, fontsize, color, fontname, fontfile, lineheight=1.35):
    """Chèn đoạn văn và trả về (chiều cao đã dùng) hoặc None nếu không đủ chỗ trên trang.

    [v3.0.1] Đo chiều cao THẬT bằng phần dư `rc` mà insert_textbox trả về,
    thay cho ước lượng theo số ký tự (vốn gây chồng chữ / hở khoảng trắng).
    """
    rect = fitz.Rect(x0, y, x1, max_y)
    if rect.height <= fontsize * 2:
        return None
    # Thử trên trang nháp để không để lại rác khi tràn
    probe = fitz.open()
    pp = probe.new_page(width=page.rect.width, height=page.rect.height)
    rc = pp.insert_textbox(rect, text, fontsize=fontsize, fontname=fontname, fontfile=fontfile,
                           lineheight=lineheight)
    probe.close()
    if rc < 0:
        return None
    page.insert_textbox(rect, text, fontsize=fontsize, color=color, fontname=fontname,
                        fontfile=fontfile, lineheight=lineheight)
    return rect.height - rc


def build_interleaved_pdf(
    source_pdf: Path,
    trans_pdf: Path,
    out_pdf: Path,
    pages: Optional[List[int]] = None,
    font_dir: Path = FONT_DIR,
) -> Path:
    """Tạo PDF Xen Đoạn (Interleaved Layout):
    Trích xuất từng khối văn bản EN và VI tương ứng, ghép xen kẽ:
    [Đoạn EN - màu xám #595959, Plus Jakarta Sans Regular]
    [Đoạn VI - màu xanh nhận diện #0a6c7d, Plus Jakarta Sans Medium, thụt lề 10 pt]
    Trang giấy có lề chuẩn, header đánh số trang song ngữ.

    [v3.0.1] Dùng font Plus Jakarta Sans nhúng (Identity-H) cho cả EN và VI.
    Bản cũ dùng Helvetica (WinAnsi) khiến toàn bộ dấu tiếng Việt thành '?'.
    """
    reg_file = str(Path(font_dir) / "PlusJakartaSans-Regular.ttf")
    med_file = str(Path(font_dir) / "PlusJakartaSans-Medium.ttf")
    for f in (reg_file, med_file):
        if not Path(f).exists():
            raise FileNotFoundError(f"Không tìm thấy font bắt buộc: {f}")
    F_REG, F_MED = "PJS-Reg", "PJS-Med"

    src_doc = fitz.open(source_pdf)
    trn_doc = fitz.open(trans_pdf)
    out_doc = fitz.open()

    page_nums = pages or list(range(1, min(src_doc.page_count, trn_doc.page_count) + 1))
    margin_x, top_y, size = 54.0, 62.0, 9.5
    gap_pair, gap_inner = 12.0, 4.0
    c_en, c_vi, c_head = (0.35, 0.35, 0.35), (0.04, 0.42, 0.49), (0.4, 0.4, 0.4)

    def new_out_page(w, h, p_label):
        pg = out_doc.new_page(width=w, height=h)
        pg.insert_text(fitz.Point(margin_x, 36), f"Bilingual Edition · Trang {p_label}", fontsize=9,
                       color=c_head, fontname=F_REG, fontfile=reg_file)
        sh = pg.new_shape()
        sh.draw_line(fitz.Point(margin_x, 44), fitz.Point(w - margin_x, 44))
        sh.finish(color=(0.8, 0.8, 0.8), width=0.5)
        sh.commit()
        return pg

    for p in page_nums:
        idx = p - 1
        if idx >= src_doc.page_count or idx >= trn_doc.page_count:
            continue
        r = src_doc[idx].rect
        src_blocks = [b for b in src_doc[idx].get_text("blocks") if b[4].strip()]
        trn_blocks = [b for b in trn_doc[idx].get_text("blocks") if b[4].strip()]

        page = new_out_page(r.width, r.height, p)
        y = top_y
        max_y = r.height - 45.0
        x1 = r.width - margin_x

        for i in range(max(len(src_blocks), len(trn_blocks))):
            en = src_blocks[i][4].strip().replace("\n", " ") if i < len(src_blocks) else ""
            vi = trn_blocks[i][4].strip().replace("\n", " ") if i < len(trn_blocks) else ""
            for text, x0, color, fname, ffile, gap in (
                (en, margin_x, c_en, F_REG, reg_file, gap_inner),
                (vi, margin_x + 10, c_vi, F_MED, med_file, gap_pair),
            ):
                if not text:
                    continue
                used = _fit_textbox(page, x0, y, x1, max_y, text, size, color, fname, ffile)
                if used is None:  # hết chỗ -> sang trang mới (cùng nhãn trang gốc)
                    page = new_out_page(r.width, r.height, p)
                    y = top_y
                    used = _fit_textbox(page, x0, y, x1, max_y, text, size, color, fname, ffile)
                    if used is None:  # đoạn dài hơn cả trang: chèn phần vừa, phần dư bị cắt có cảnh báo
                        print(f"[WARN] Trang {p}: đoạn {i} dài hơn 1 trang, cần tách thủ công.", file=sys.stderr)
                        used = max_y - y
                y += used + gap

    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    out_doc.subset_fonts()
    out_doc.save(str(out_pdf), garbage=3, deflate=True)
    out_doc.close()
    src_doc.close()
    trn_doc.close()
    return out_pdf


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_facing = sub.add_parser("facing", help="Tạo Layout A: Đối trang (Facing Book / Sheet)")
    p_facing.add_argument("--source", required=True, help="PDF gốc tiếng Anh")
    p_facing.add_argument("--trans", required=True, help="PDF dịch tiếng Việt")
    p_facing.add_argument("--pages", default="all", help="Phạm vi trang (VD: 1,2,4-6)")
    p_facing.add_argument("--out-book", default="", help="Đường dẫn file facing_book.pdf")
    p_facing.add_argument("--out-sheet", default="", help="Đường dẫn file facing_sheet.pdf")

    p_inter = sub.add_parser("interleaved", help="Tạo Layout B: Xen đoạn (Interleaved)")
    p_inter.add_argument("--source", required=True, help="PDF gốc tiếng Anh")
    p_inter.add_argument("--trans", required=True, help="PDF dịch tiếng Việt")
    p_inter.add_argument("--pages", default="all", help="Phạm vi trang (VD: 1,2,4-6)")
    p_inter.add_argument("--out", required=True, help="Đường dẫn file interleaved.pdf")

    args = parser.parse_args()

    src_p = Path(args.source)
    trn_p = Path(args.trans)

    src_doc = fitz.open(src_p)
    page_list = parse_page_range(args.pages, src_doc.page_count)
    src_doc.close()

    if args.cmd == "facing":
        if args.out_book:
            out_b = Path(args.out_book)
            build_facing_book_pdf(src_p, trn_p, out_b, page_list)
            print(f"[OK] Đã xuất Facing Book PDF: {out_b}")
        if args.out_sheet:
            out_s = Path(args.out_sheet)
            build_facing_sheet_pdf(src_p, trn_p, out_s, page_list)
            print(f"[OK] Đã xuất Facing Sheet PDF (2-up): {out_s}")
        return 0

    if args.cmd == "interleaved":
        out_i = Path(args.out)
        build_interleaved_pdf(src_p, trn_p, out_i, page_list)
        print(f"[OK] Đã xuất Interleaved PDF: {out_i}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
