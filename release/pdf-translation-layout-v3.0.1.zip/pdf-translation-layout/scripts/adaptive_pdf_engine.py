"""
adaptive_pdf_engine.py
Engine dàn trang thích ứng vector đa vùng (Zone-Bounded Adaptive Layout Engine).
Bảo tồn 100% vector text layers, né ảnh chân dung đa phía, khử vệt trắng Skia, và căn chỉnh ô bảng.
"""

import argparse
import json
import os
import re
import pymupdf as fitz


DEFAULT_FONT_FILES = {
    "regular": ("PJS-Regular", "PlusJakartaSans-Regular.ttf"),
    "medium": ("PJS-Medium", "PlusJakartaSans-Medium.ttf"),
    "semibold": ("PJS-SemiBold", "PlusJakartaSans-SemiBold.ttf"),
    "italic": ("PJS-Italic", "PlusJakartaSans-Italic.ttf"),
    "bold_italic": ("PJS-BoldItalic", "PlusJakartaSans-SemiBoldItalic.ttf"),
    "superscript": ("PJS-Regular", "PlusJakartaSans-Regular.ttf"),
}


def hex_to_rgb(hex_str):
    h = (hex_str or "#2a2e30").lstrip("#")
    if len(h) != 6:
        return (0.165, 0.18, 0.188)
    return tuple(int(h[i : i + 2], 16) / 255.0 for i in (0, 2, 4))


def clean_page_stream(doc, page, pno):
    """
    Xóa bỏ toàn bộ các khối chữ tiếng Anh cũ BT...ET, đường cong Bézier vector,
    và các hộp chữ nhật trắng lót dòng của Google Docs (h < 100 pt),
    giữ nguyên vẹn 100% hình ảnh, khung kẻ và màu nền xám bảng biểu #f5f5f5.
    """
    xrefs = page.get_contents()
    if not xrefs:
        return
    raw_bytes = page.read_contents()
    stream = raw_bytes.decode("latin1")

    # 1. Xóa BT ... ET
    stream = re.sub(r"BT\b.*?ET\b", "", stream, flags=re.DOTALL)

    # 2. Xóa vector glyph outline đặc thù trên Trang 4 nếu có
    if pno == 4:
        stream = re.sub(
            r"\.1647 \.1804 \.1882 RG \.1647 \.1804 \.1882 rg\s*/G3 gs\s*(?:[\d\.\-\s]+[mclh]\s*)+f\s*",
            "",
            stream,
        )

    # 3. Lọc bỏ các hộp trắng lót dòng nhỏ (h < 100 pt)
    def strip_line_white_rect(m):
        w, h = float(m.group(1)), float(m.group(2))
        if h < 100.0:
            return ""
        return m.group(0)

    stream = re.sub(
        r"1 1 1 RG 1 1 1 rg\s*/G3 gs\s*[\d\.\-]+\s+[\d\.\-]+\s+([\d\.\-]+)\s+([\d\.\-]+)\s+re\s*f",
        strip_line_white_rect,
        stream,
    )

    doc.update_stream(xrefs[0], stream.encode("latin1"))
    for extra_xref in xrefs[1:]:
        doc.update_stream(extra_xref, b"")

    for lk in list(page.get_links()):
        page.delete_link(lk)


def tokenize_runs(runs, font_files):
    tokens = []
    for run in runs:
        text = run.get("text", "")
        if not text:
            continue
        style = run.get("style", "regular")
        if style not in font_files:
            style = "regular"
        color = run.get("color", "#2a2e30")
        link = run.get("link", None)

        if style == "superscript":
            tokens.append({
                "text": text.strip(),
                "style": style,
                "color": color,
                "link": link,
                "is_space": False,
                "no_break_before": True,
            })
            continue

        parts = re.split(r"(\s+)", text)
        for part in parts:
            if not part:
                continue
            is_sp = part.isspace()
            tokens.append({
                "text": part,
                "style": style,
                "color": color,
                "link": link,
                "is_space": is_sp,
                "no_break_before": False,
            })
    return tokens


def wrap_block_lines(block, y_start, font_objs, font_files, size_override=None, leading_override=None, x1_max_override=None):
    base_x0 = block["x0"]
    base_x1_max = x1_max_override if x1_max_override is not None else block["x1_max"]
    size = size_override if size_override is not None else block["size"]
    leading = leading_override if leading_override is not None else block["leading"]
    avoid_rect = block.get("wrap_avoid_rect")
    avoid_left_rect = block.get("wrap_avoid_left_rect")

    tokens = tokenize_runs(block["runs"], font_files)
    units = []
    for tok in tokens:
        if tok.get("no_break_before") and units and not units[-1][0]["is_space"]:
            units[-1].append(tok)
        else:
            units.append([tok])

    lines = []
    cur_y_top = y_start

    def get_line_x_bounds(y_top):
        lx0 = base_x0
        lx1 = base_x1_max
        if avoid_rect:
            ax0, ay0, ax1, ay1 = avoid_rect
            if (y_top + size) >= ay0 and y_top <= ay1:
                lx1 = min(lx1, ax0 - 4.0)
        if avoid_left_rect:
            ax0, ay0, ax1, ay1 = avoid_left_rect
            if (y_top + size) >= ay0 and y_top <= ay1:
                lx0 = max(lx0, ax1)
        return lx0, lx1

    cur_x0, cur_x1_max = get_line_x_bounds(cur_y_top)
    cur_x = cur_x0
    cur_tokens = []

    for unit in units:
        if not cur_tokens and len(unit) == 1 and unit[0]["is_space"]:
            continue

        unit_w = 0.0
        for tok in unit:
            f_obj = font_objs[tok["style"]]
            sz = round(size * 0.62, 2) if tok["style"] == "superscript" else size
            unit_w += f_obj.text_length(tok["text"], fontsize=sz)

        if cur_tokens and (cur_x + unit_w > cur_x1_max):
            while cur_tokens and cur_tokens[-1]["is_space"]:
                cur_tokens.pop()
            lines.append({
                "tokens": cur_tokens,
                "x0": cur_x0,
                "x1": cur_x,
                "y_top": cur_y_top,
                "y_baseline": cur_y_top + size * 0.82,
                "y_bot": cur_y_top + leading,
            })
            cur_y_top += leading
            cur_x0, cur_x1_max = get_line_x_bounds(cur_y_top)
            cur_x = cur_x0
            cur_tokens = []
            if len(unit) == 1 and unit[0]["is_space"]:
                continue

        for tok in unit:
            cur_tokens.append(tok)
        cur_x += unit_w

    if cur_tokens:
        while cur_tokens and cur_tokens[-1]["is_space"]:
            cur_tokens.pop()
        if cur_tokens:
            lines.append({
                "tokens": cur_tokens,
                "x0": cur_x0,
                "x1": cur_x,
                "y_top": cur_y_top,
                "y_baseline": cur_y_top + size * 0.82,
                "y_bot": cur_y_top + leading,
            })

    return lines


def partition_into_zones(blocks, page_img_rects=None):
    if not blocks:
        return []

    page_img_rects = page_img_rects or []

    for b in blocks:
        b_y0 = b.get("y0")
        bx0 = b.get("x0", 72.0)
        bx1 = b.get("x1_max", 540.0)
        if b_y0 is not None:
            for img_r in page_img_rects:
                h_overlap = min(bx1, img_r.x1) - max(bx0, img_r.x0)
                if h_overlap > 20.0 and img_r.y0 < b_y0 <= img_r.y1 + 4.0:
                    b["y0"] = round(img_r.y1 + 5.0, 2)

    zones = []
    cur_zone = []
    for b in blocks:
        if not cur_zone:
            cur_zone.append(b)
            continue
        same_zone_id = b.get("zone_id") == cur_zone[-1].get("zone_id")
        is_flowing = b.get("flow", False)
        if is_flowing and (same_zone_id or b.get("zone_id") is None):
            cur_zone.append(b)
        else:
            zones.append(cur_zone)
            cur_zone = [b]
    if cur_zone:
        zones.append(cur_zone)

    # Footnote ascending sort
    for z in zones:
        if all(b.get("y0") is not None for b in z):
            z.sort(key=lambda b: b["y0"])

    for z_idx, z_blocks in enumerate(zones):
        explicit_max = z_blocks[0].get("zone_y1_max")
        if explicit_max is not None:
            z_max = explicit_max
        elif z_idx + 1 < len(zones):
            next_y0 = zones[z_idx + 1][0].get("y0", 744.0)
            if next_y0 > (z_blocks[0].get("y0") or 0.0) + 15.0:
                z_max = next_y0 - 4.0
            else:
                z_max = 744.0
        else:
            z_max = 744.0

        z_y0 = z_blocks[0].get("y0", 0.0) or 0.0
        for img_r in page_img_rects:
            if img_r.y0 > z_y0 + 20.0 and img_r.y0 < z_max:
                if img_r.x1 > 72.0 and img_r.x0 < 540.0:
                    z_max = min(z_max, round(img_r.y0 - 6.0, 2))

        for b in z_blocks:
            b["_effective_zone_y1_max"] = z_max

    return zones


def layout_zone_with_adaptive_fit(z_blocks, font_objs, font_files):
    z_max = z_blocks[0]["_effective_zone_y1_max"]
    scales = [1.0, 0.97, 0.94, 0.91, 0.88, 0.85, 0.82, 0.79, 0.76, 0.73, 0.70, 0.67]

    best_plan = None
    for sc in scales:
        y_cursor = z_blocks[0].get("y0", 56.4)
        plan = []
        max_y_bot = y_cursor

        for b in z_blocks:
            y_start = y_cursor if b.get("flow", False) else b.get("y0", y_cursor)
            sz = round(b["size"] * sc, 2)
            lead = round(b["leading"] * (1.0 if sc == 1.0 else sc * 0.96), 2)
            sp_after = round(b.get("space_after", 0.0) * (1.0 if sc == 1.0 else sc * 0.82), 2)
            x1_m = b["x1_max"]
            if sc < 0.95 and x1_m >= 530.0 and x1_m < 548.0:
                x1_m = min(548.0, x1_m + 6.0)

            lines = wrap_block_lines(
                b, y_start, font_objs, font_files, size_override=sz, leading_override=lead, x1_max_override=x1_m
            )

            # Table cell vertical centering
            cbounds = b.get("cell_bounds")
            if cbounds and lines:
                cx0, cy0, cx1, cy1 = cbounds
                total_h = lines[-1]["y_bot"] - lines[0]["y_top"]
                avail_h = cy1 - cy0
                if lines[-1]["y_bot"] > cy1 - 2.0 and total_h <= avail_h - 2.0:
                    new_y_start = round(cy0 + max(2.0, (avail_h - total_h) / 2.0), 2)
                    lines = wrap_block_lines(
                        b, new_y_start, font_objs, font_files, size_override=sz, leading_override=lead, x1_max_override=x1_m
                    )
                    y_start = new_y_start

            if lines:
                max_y_bot = max(max_y_bot, lines[-1]["y_bot"])
                y_cursor = lines[-1]["y_top"] + lead + sp_after
            plan.append({
                "block": b,
                "y_start": y_start,
                "size": sz,
                "leading": lead,
                "lines": lines,
            })

        best_plan = plan
        if max_y_bot <= z_max:
            break

    return best_plan


def compile_translated_pdf(source_pdf, translations_json, output_pdf, font_dir, base_dir=".", pages=None):
    with open(translations_json, encoding="utf-8") as f:
        translations = json.load(f)

    font_files = {}
    for k, (fname, ffile) in DEFAULT_FONT_FILES.items():
        fpath = os.path.join(font_dir, ffile)
        if not os.path.exists(fpath):
            raise FileNotFoundError(f"Không tìm thấy font bắt buộc: {fpath}")
        font_files[k] = (fname, fpath)

    font_objs = {k: fitz.Font(fontfile=fpath) for k, (_, fpath) in font_files.items()}
    doc = fitz.open(source_pdf)

    layout_log = {}
    pnos = sorted(int(k) for k in translations.keys())
    if pages:  # [v3.0.1] lọc phạm vi trang theo --pages
        pnos = [p for p in pnos if p in set(pages)]

    for pno in pnos:
        page = doc[pno - 1]
        clean_page_stream(doc, page, pno)

        for style_key, (fname, fpath) in font_files.items():
            page.insert_font(fontname=fname, fontfile=fpath)

        page_img_xrefs = [img[0] for img in page.get_images()]
        for rep in translations[str(pno)].get("replace_images", []):
            img_path = os.path.join(base_dir, rep["path"])
            if not os.path.exists(img_path):
                continue
            target_xref = rep["xref"] if rep["xref"] in page_img_xrefs else (page_img_xrefs[0] if page_img_xrefs else rep["xref"])
            page.replace_image(target_xref, filename=img_path)

        page_img_rects = []
        for img in page.get_images():
            for r in page.get_image_rects(img[0]):
                page_img_rects.append(r)

        placed_bboxes = []
        zones = partition_into_zones(translations[str(pno)].get("blocks", []), page_img_rects=page_img_rects)

        for z_blocks in zones:
            zone_plan = layout_zone_with_adaptive_fit(z_blocks, font_objs, font_files)
            for item in zone_plan:
                block = item["block"]
                size = item["size"]
                lines = item["lines"]

                if "bullet_text" in block and block["bullet_text"]:
                    bx0 = block.get("bullet_x0", 90.0)
                    btxt = block["bullet_text"]
                    b_fname, _ = font_files["regular"]
                    page.insert_text(
                        fitz.Point(bx0, item["y_start"] + size * 0.78),
                        btxt,
                        fontname=b_fname,
                        fontsize=size,
                        color=hex_to_rgb("#2a2e30"),
                    )

                for ln in lines:
                    cur_x = ln["x0"]
                    for tok in ln["tokens"]:
                        style = tok["style"]
                        run_size = round(size * 0.62, 2) if style == "superscript" else size
                        run_y_base = ln["y_top"] + run_size * 0.60 if style == "superscript" else ln["y_baseline"]
                        fname, _ = font_files[style]
                        draw_text = tok["text"]
                        w = font_objs[style].text_length(draw_text, fontsize=run_size)

                        page.insert_text(
                            fitz.Point(cur_x, run_y_base),
                            draw_text,
                            fontname=fname,
                            fontsize=run_size,
                            color=hex_to_rgb(tok["color"]),
                        )

                        run_rect = fitz.Rect(cur_x, ln["y_top"] - 1.0, cur_x + w, ln["y_bot"] + 2.0)
                        placed_bboxes.append({
                            "block_id": block["id"],
                            "text": draw_text,
                            "rect": [round(v, 2) for v in run_rect],
                        })

                        lk = tok.get("link")
                        if lk:
                            if lk.get("uri"):
                                page.insert_link({"kind": fitz.LINK_URI, "from": run_rect, "uri": lk["uri"]})
                            elif lk.get("page") is not None:
                                page.insert_link({"kind": fitz.LINK_GOTO, "from": run_rect, "page": lk["page"]})

                        cur_x += w

        layout_log[str(pno)] = placed_bboxes

    doc.subset_fonts()
    os.makedirs(os.path.dirname(output_pdf) or ".", exist_ok=True)
    doc.save(output_pdf, garbage=1, deflate=True)
    doc.close()
    # [v3.0.1] Lưu layout log cạnh file PDF để Cổng QA tầng Hình học có dữ liệu kiểm tra
    log_path = os.path.splitext(output_pdf)[0] + "_layout_log.json"
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(layout_log, f, ensure_ascii=False)
    print(f"Biên dịch PDF thành công: {output_pdf} ({len(pnos)} trang)")
    print(f"Layout log (cho lệnh qa): {log_path}")


def _parse_pages(spec):
    """'1,2,4-6' -> [1, 2, 4, 5, 6]; rỗng -> None (toàn bộ)."""
    if not spec:
        return None
    out = []
    for part in str(spec).split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def main():
    default_fonts = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "fonts")
    parser = argparse.ArgumentParser(description="Engine dàn trang thích ứng vector PDF.")
    parser.add_argument("--source", "-s", required=True, help="File PDF nguồn")
    parser.add_argument("--trans", "-t", required=True, help="File JSON bản dịch")
    parser.add_argument("--output", "-o", required=True, help="File PDF kết xuất")
    parser.add_argument("--fonts", "-f", default=default_fonts, help="Thư mục chứa font tĩnh TTF (mặc định: assets/fonts)")
    parser.add_argument("--pages", default="", help="Phạm vi trang cần dàn (vd: 1-10,15). Mặc định: mọi trang có bản dịch")
    args = parser.parse_args()

    compile_translated_pdf(args.source, args.trans, args.output, args.fonts, pages=_parse_pages(args.pages))


if __name__ == "__main__":
    main()
