# Nhật ký thay đổi

## 3.0.1 — 01/11/2026 (bản phát hành công khai đầu tiên)

Sửa 4 lỗi phát hiện khi chạy thử lại toàn bộ lệnh CLI trên máy sạch:

1. **`cli.py translate-mono` không chạy được** — engine yêu cầu tham số `--fonts` nhưng CLI không truyền, đồng thời CLI truyền `--pages` mà engine không nhận.
   → CLI tự trỏ tới `assets/fonts`, engine hỗ trợ `--pages` (vd `1-10,15`).
2. **Chế độ Xen đoạn (Interleaved) mất dấu tiếng Việt** — dùng font Helvetica (WinAnsi) nên mọi ký tự có dấu thành `?`; chiều cao đoạn ước lượng theo số ký tự gây chồng chữ/hở trắng.
   → Nhúng Plus Jakarta Sans (Identity-H), đo chiều cao thật của từng đoạn, tự sang trang khi hết chỗ.
3. **Cổng QA tầng Hình học kiểm 0 dòng chữ nhưng vẫn báo "0 vi phạm"** — engine không lưu layout log nên QA không có dữ liệu.
   → `translate-mono` ghi `<tên_file>_layout_log.json` cạnh PDF; `cli.py qa` tự dò file này và cảnh báo rõ khi thiếu.
4. **Video đọc sách ghi sai tiêu đề và số trang** — tiêu đề cố định “CẨM NANG KHỞI ĐẦU” cho mọi tài liệu, số trang hiện “13 / 6” (chia cho số trang được chọn), mũi tên “➔” không có trong font nên thành ô lỗi.
   → Tiêu đề lấy từ `title` trong manifest, số trang so với tổng trang tài liệu (“13 / 163”), dùng mũi tên “→”.

Khác:
- Thêm `LICENSE` (MIT) và `assets/fonts/OFL.txt` (giấy phép font Plus Jakarta Sans).
- Bỏ khỏi gói phát hành các script và dữ liệu dành riêng cho dự án dịch sách mẫu (chứa đường dẫn máy cá nhân và bản dịch nội dung sách).
- Sửa đường dẫn cá nhân trong `GUIDE_CLAUDE.md`.

## 3.0.0
- Hệ sinh thái 3 chế độ: Đơn ngữ, Song ngữ (Đối trang / Xen đoạn), Đa phương tiện (Voice Studio + Video 1080p), Cổng QA 4 tầng.
