# Cẩm Nang Sử Dụng Skill `pdf-translation-layout` Trong Antigravity IDE

Tài liệu này hướng dẫn chi tiết cách cài đặt, kích hoạt và khai thác tối đa sức mạnh của hệ sinh thái **`pdf-translation-layout` v3.0** ngay trong giao diện Antigravity IDE.

---

## 1. Cài Đặt & Kích Hoạt Tự Động

Skill `pdf-translation-layout` được lưu trữ tại:
`%USERPROFILE%\.gemini\config\skills\pdf-translation-layout`

### Kiểm tra nhận diện của Antigravity IDE:
Antigravity IDE tự động quét thư mục skills khi khởi động. Bạn có thể kiểm tra danh sách skills bằng cách gõ trong khung chat:
```text
/pdf-translation-layout
```
hoặc gọi qua câu lệnh tự nhiên:
- *"Dịch tài liệu PDF này sang tiếng Việt giữ nguyên layout"*
- *"Tạo sách song ngữ đối trang cho file book.pdf"*
- *"Lồng tiếng và xuất video đọc sách 1080p"*

---

## 2. Quy Trình Làm Việc Tiêu Chuẩn Trong Antigravity (KWSR Framework)

Antigravity hoạt động theo mô hình Agentic System với các Artifacts cốt lõi (`task.md`, `implementation_plan.md`, `walkthrough.md`):

### Bước 1: Khởi Tạo Dự Án & Lập Kế Hoạch (Planning Mode)
Khi bạn gửi một tệp PDF vào khung chat, Antigravity sẽ tự động kích hoạt skill và đề xuất kế hoạch:
```text
User: "Hãy dịch tài liệu D:\Books\sample.pdf giữ nguyên layout và xuất thêm bản song ngữ đối trang."
```
Agent sẽ:
1. Đọc file PDF nguồn ở chế độ chỉ đọc.
2. Gọi `python scripts/cli.py inspect --source D:\Books\sample.pdf` để kiểm kê số trang, kích thước và phân bố hình ảnh.
3. Tạo file `task.md` với các mốc kiểm tra.

### Bước 2: Dịch Thuật Bảo Tồn Run-Level Style
Agent phân tích từng khối văn bản (`block` / `span`), bảo tồn các định dạng in đậm, in nghiêng, liên kết đích và tạo bảng thuật ngữ chuyên ngành `docs/glossary.md`.

### Bước 3: Dàn Trang Vector Thích Ứng (Execution Mode)
Agent thực thi lệnh dàn trang:
- **Dịch đơn ngữ**:
  ```bash
  python scripts/cli.py translate-mono --source D:\Books\sample.pdf --trans data/translations.json --out output/sample_VI_v1.pdf
  ```
- **Tạo sách song ngữ Đối trang (Facing) & Xen đoạn (Interleaved)**:
  ```bash
  python scripts/cli.py bilingual --source D:\Books\sample.pdf --trans output/sample_VI_v1.pdf --mode all
  ```

### Bước 4: Lồng Tiếng Voice Studio & Xuất Video 1080p
Nếu bạn yêu cầu xuất video đọc sách:
```text
User: "Lồng tiếng bản song ngữ và xuất video 1080p cho 5 trang đầu."
```
Agent sẽ:
1. Gọi `voice_studio.py` để sinh âm thanh giọng đọc tiếng Anh (`Andrew`) và tiếng Việt (`Đức Trí`).
2. Gọi `reading_video_engine.py` với cờ `--mode bilingual` để tạo tệp MP4 đạt chuẩn broadcast (25fps constant framerate, 48,000 Hz AAC, đồng bộ bounding box highlight).

### Bước 5: Kiểm Định Chất Lượng QA 4 Tầng & Nghiệm Thu
Agent chạy `qa_verifier.py` và cập nhật kết quả vào `walkthrough.md`:
- Đảm bảo **`0` ký tự tofu lỗi font**.
- Đảm bảo **`0` vi phạm tràn lề** hoặc đè lên hình ảnh.
- Xuất liên kết trực tiếp tới các tệp đầu ra (`file:///...`).

---

## 3. Các Phím Tắt & Lệnh Thao Tác Nhanh

- **Gõ `/pdf-translation-layout`**: Kích hoạt ngữ cảnh chuyên gia dàn trang PDF.
- **Yêu cầu clone giọng đọc**:
  ```text
  "Nhân bản giọng nói của tôi từ file sample.wav để làm giọng đọc tiếng Việt cho sách."
  ```
- **Xem trước video preview**:
  Sau khi render xong, bạn có thể click vào đường dẫn `output/...mp4` hiển thị trong chat để mở video trên trình phát media của Windows.
