# CLAUDE.md — Quy Chuẩn Vận Hành Cho Claude Code (v3.0)

Tệp này hướng dẫn **Claude Code CLI** và **Claude Desktop** tự động nhận diện và vận hành hệ sinh thái `pdf-translation-layout` v3.0 mà không cần cấu hình phức tạp.

---

## 1. Tổng Quan Kỹ Năng
Khi người dùng yêu cầu dịch PDF, dàn trang PDF, tạo sách song ngữ, lồng tiếng AI hoặc xuất video đọc sách:
- **Tuyệt đối không ảnh hóa (Zero-Rasterization)**: Giữ 100% Vector Text Layer thật.
- **Sử dụng CLI trung tâm**: Luôn ưu tiên chạy lệnh qua `python scripts/cli.py <subcommand>`.
- **Hệ màu & Font chuẩn**: Dùng họ font `assets/fonts/PlusJakartaSans-*.ttf`.

---

## 2. Quy Trình Claude Code Thực Hiện Tự Động

Mỗi khi nhận một tệp PDF đầu vào:
1. **Kiểm kê nguồn**:
   ```bash
   python scripts/cli.py inspect --source <file.pdf> --out-dir data/
   ```
   Đọc `data/full_book_raw.json` để nắm số trang, phân bố text, ảnh, và tọa độ.
2. **Dịch thuật**:
   - Dịch theo từng batch (20–25 trang/lần) để tránh tràn context window.
   - Bảo toàn 1-1 các thẻ in đậm, in nghiêng, và chỉ số trên (`superscript`).
   - Ghi vào `data/full_book_translations.json`.
3. **Dàn trang**:
   - **Đơn ngữ**:
     ```bash
     python scripts/cli.py translate-mono --source <file.pdf> --trans data/full_book_translations.json --out output/<file>_VI_v1.pdf
     ```
   - **Song ngữ (Facing & Interleaved)**:
     ```bash
     python scripts/cli.py bilingual --source <file.pdf> --trans output/<file>_VI_v1.pdf --mode all
     ```
4. **Kiểm định chất lượng**:
   ```bash
   python scripts/cli.py qa --source <file.pdf> --target output/<file>_VI_v1.pdf --report output/qa_report.json
   ```
   Nếu `qa_report.json` báo có vi phạm (lề hoặc ký tự tofu), Claude Code phải phân tích tọa độ lỗi và tự sửa lại trước khi báo cáo hoàn tất cho người dùng.

---

## 3. Lệnh Thường Dùng Khi Người Dùng Yêu Cầu

| Yêu cầu của người dùng | Lệnh Claude Code thực thi |
| :--- | :--- |
| "Kiểm tra cấu trúc file PDF này" | `python scripts/cli.py inspect --source <file.pdf>` |
| "Dịch sang tiếng Việt giữ nguyên layout" | `python scripts/cli.py translate-mono --source <file.pdf> --trans trans.json --out out.pdf` |
| "Tạo sách song ngữ đối trang" | `python scripts/cli.py bilingual --source en.pdf --trans vi.pdf --mode facing` |
| "Tạo sách song ngữ xen đoạn" | `python scripts/cli.py bilingual --source en.pdf --trans vi.pdf --mode interleaved` |
| "Lồng tiếng / đọc văn bản" | `python scripts/cli.py voice synth --lang vi --voice "Đức Trí" --text "..." --out out.wav` |
| "Nhân bản giọng nói từ mẫu" | `python scripts/cli.py voice clone --name "Tên" --lang vi --ref sample.wav --ref-text "..."` |
| "Xuất video đọc sách 1080p" | `python scripts/cli.py video --source en.pdf --trans vi.pdf --manifest mf.json --mode bilingual --out video.mp4` |
| "Kiểm định chất lượng file dịch" | `python scripts/cli.py qa --source en.pdf --target vi.pdf` |
