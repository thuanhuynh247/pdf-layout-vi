# Cẩm Nang Sử Dụng Skill `pdf-translation-layout` Cho Claude Code CLI

Tài liệu này hướng dẫn các kỹ sư sử dụng **Claude Code CLI** (`claude`) của Anthropic để dịch, dàn trang vector và xuất bản ấn phẩm song ngữ đa phương tiện tự động.

---

## 1. Cài Đặt Skill Vào Dự Án Claude Code

### Cách 1: Sử Dụng Trực Tiếp Trong Thư Mục Dự Án (Khuyên Dùng)
Khi bạn mở Terminal và chạy lệnh `claude` tại thư mục chứa repository:
```bash
cd pdf-translation-layout
claude
```
Claude Code sẽ tự động đọc tệp [`CLAUDE.md`](CLAUDE.md) ở gốc thư mục và nạp toàn bộ quy chuẩn, phím tắt và hướng dẫn vận hành vào bộ nhớ làm việc.

### Cách 2: Cài Đặt Vào Thư Mục Toàn Cục Của Claude Code
Nếu muốn sử dụng skill ở bất kỳ thư mục nào trên máy tính, bạn chỉ cần sao chép thư mục skill vào cấu hình toàn cục:
```bash
# Trên Windows:
:: Chạy tại thư mục chứa folder pdf-translation-layout vừa giải nén
xcopy /E /I "pdf-translation-layout" "%USERPROFILE%\.claude\skills\pdf-translation-layout"

# Trên macOS / Linux:
cp -r pdf-translation-layout ~/.claude/skills/
```

---

## 2. Các Kịch Bản Ra Lệnh Cho Claude Code

Claude Code có khả năng tự động phân tích mã lỗi và tự gọi script Python thông qua công cụ Bash/Terminal.

### Kịch Bản 1: Dịch Toàn Bộ Tài Liệu Giữ Nguyên Bố Cục
```text
> claude
Claude> Hãy dịch tài liệu ./sample.pdf sang tiếng Việt, giữ nguyên 100% vector layout, font chữ và hình ảnh gốc.
```
*Claude Code sẽ tự động*:
1. Chạy `python scripts/cli.py inspect --source ./sample.pdf`.
2. Trích xuất text, chia nhỏ thành các batch hợp lý.
3. Dịch từng khối văn bản và lưu vào `data/translations.json`.
4. Gọi `python scripts/cli.py translate-mono --source ./sample.pdf --trans data/translations.json --out output/sample_VI.pdf`.
5. Chạy `qa_verifier.py` để xác nhận 0 ký tự tofu trước khi trả lời.

---

### Kịch Bản 2: Xuất Bản Sách Song Ngữ Đối Trang (Facing Book)
```text
Claude> Tạo bản sách song ngữ đối trang cho file sample.pdf và sample_VI.pdf để tôi in khổ 2 trang.
```
*Claude Code sẽ thực thi*:
```bash
python scripts/cli.py bilingual --source sample.pdf --trans sample_VI.pdf --mode facing --out-book output/facing_book.pdf --out-sheet output/facing_sheet.pdf
```
Kết quả trả về sẽ gồm:
- `output/facing_book.pdf`: Số trang gấp đôi, mở chế độ 2-Page View luôn thấy Trái EN - Phải VI.
- `output/facing_sheet.pdf`: Bản ghép khổ đôi liền nhau sẵn sàng in ấn.

---

### Kịch Bản 3: Xuất Video Đọc Sách Song Ngữ 1080p
```text
Claude> Hãy lồng tiếng cho 5 trang đầu của cuốn sách và xuất video 1080p đọc song ngữ đan xen.
```
*Claude Code sẽ thực thi*:
1. Gọi `voice_studio.py` để tổng hợp giọng đọc cho từng câu thoại.
2. Gọi `python scripts/cli.py video --source sample.pdf --trans sample_VI.pdf --manifest data/manifest.json --mode bilingual --pages 1,2,3,4,5 --out output/video_bilingual.mp4`.
3. Kiểm tra thông số FFmpeg: 1920x1080 @ 25fps constant, audio 48kHz AAC, đảm bảo âm thanh trong trẻo, không bị méo tiếng.

---

## 3. Mẹo Dành Riêng Cho Kỹ Sư Claude Code

1. **Kiểm Soát Bộ Nhớ Context Window**: Với tài liệu trên 50 trang, hãy bảo Claude:
   ```text
   "Hãy dịch tài liệu này theo từng phần 20 trang một để tiết kiệm token và đảm bảo độ chính xác."
   ```
2. **Kiểm Tra Lỗi Tự Động**: Sau khi chạy xong, hãy yêu cầu:
   ```text
   "Kiểm tra file qa_report.json, nếu có bất kỳ cảnh báo nào hãy tự động fix lại."
   ```
   Claude sẽ đọc tọa độ trong `qa_report.json` và tự động điều chỉnh tham số scale `sc` trong `adaptive_pdf_engine.py`.
