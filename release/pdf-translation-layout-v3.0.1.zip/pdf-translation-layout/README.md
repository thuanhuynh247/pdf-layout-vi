# 📚 Universal Vector PDF & Media Publishing Ecosystem v3.0
### Hệ Sinh Thái Dịch Thuật, Dàn Trang Vector Thích Ứng & Xuất Bản Đa Phương Tiện Song Ngữ

[![Version](https://img.shields.io/badge/version-3.0.1-blue.svg)](CHANGELOG.md)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/)
[![Antigravity](https://img.shields.io/badge/Platform-Antigravity%20IDE-orange.svg)](https://deepmind.google/)
[![Claude Code](https://img.shields.io/badge/Platform-Claude%20Code-purple.svg)](https://anthropic.com/)
[![ChatGPT](https://img.shields.io/badge/Platform-OpenAI%20ChatGPT-teal.svg)](https://openai.com/)
[![Zero-Rasterization](https://img.shields.io/badge/Vector-100%25%20Selectable-success.svg)](#)

---

## 🌟 1. Giới Thiệu Tổng Quan

**`pdf-translation-layout` v3.0** là giải pháp xuất bản tài liệu kỹ thuật số thế hệ mới, giải quyết triệt để vấn đề muôn thuở của việc dịch PDF: **Văn bản bị ảnh hóa làm mờ chữ, mất khả năng sao chép/tìm kiếm (`Ctrl+F`), vỡ bố cục khi in ấn, hoặc chữ tiếng Việt nở ra làm tràn lề**.

Được xây dựng theo triết lý kỹ sư thực chứng (**Skills for Real Engineers — Anti-Vibe Coding**), hệ sinh thái mang lại:
1. **100% Vector Text Layer Thật (Zero-Rasterization)**: Toàn bộ chữ trong sách là văn bản vector sắc nét tuyệt đối ở mọi mức thu phóng (Zoom 500%), cho phép bôi đen, sao chép và tìm kiếm.
2. **3 Chế Độ Bố Cục Toàn Diện**:
   - **Đơn ngữ (Mono-Target)**: Bản dịch tiếng Việt bảo tồn 100% bố cục và hình minh họa gốc.
   - **Đối trang (Facing Book / 2-Up Sheet)**: Mở sách 1-1 (Trang trái EN gốc | Trang phải VI dịch), tương thích tự nhiên máy in và phòng đọc 3D.
   - **Xen đoạn (Interleaved Flow)**: Mỗi đoạn tiếng Anh đi liền đoạn dịch tiếng Việt được tô màu nhận diện (`#0a7a8c`).
3. **Phòng Thu Giọng Đọc AI VieNeu-TTS v3**: Tích hợp các giọng đọc tiếng Việt truyền cảm (`Đức Trí`, `Minh Quân`, `Trúc Ly`) và tiếng Anh bản ngữ (`Andrew`, `Adam`), hỗ trợ **Nhân bản Giọng nói tức thì (Instant Voice Cloning)** từ đoạn mẫu 3–8 giây.
4. **Engine Dựng Video Đọc Sách 1080p Broadcast Standard**: Xuất bản video Full HD (1920x1080 @ 25fps constant framerate, 48,000 Hz AAC), tự động highlight đoạn văn bản đang đọc theo bounding box và phụ đề 2 dòng nảy nhịp.
5. **Cổng Kiểm Định QA 4 Tầng Tự Động**: Đảm bảo 100% không có ký tự tofu lỗi font (`0 tofu`), 0 vi phạm hình học/tràn lề.

---

## 🏗️ 2. Sơ Đồ Kiến Trúc Hệ Sinh Thái

```
                          ┌───────────────────────────┐
                          │   Tài Liệu PDF Nguồn      │
                          └─────────────┬─────────────┘
                                        │
                                        ▼
                          ┌───────────────────────────┐
                          │     Kiểm Kê Cơ Khí        │
                          │ (scripts/inventory_extr.) │
                          └─────────────┬─────────────┘
                                        │
             ┌──────────────────────────┼──────────────────────────┐
             ▼                          ▼                          ▼
┌─────────────────────────┐┌─────────────────────────┐┌─────────────────────────┐
│   Chế Độ Đơn Ngữ        ││   Chế Độ Song Ngữ       ││   Chế Độ Đa Phương Tiện │
│ (adaptive_pdf_engine)   ││ (bilingual_layouts)     ││ (voice_studio & video)  │
├─────────────────────────┤├─────────────────────────┤├─────────────────────────┤
│ • Zone Partitioning     ││ • Layout A: Đối Trang   ││ • VieNeu-TTS v3 (Đức Trí)│
│ • Bậc thang Fitting sc  ││   - facing_book.pdf     ││ • Giọng Mỹ (Andrew)     │
│ • Bilateral Wrap tránh ảnh│ • Layout B: Xen Đoạn   ││ • Voice Cloning 3-8s    │
│ • Khử vệt trắng Skia    ││   - interleaved.pdf     ││ • Video 1080p Broadcast │
└────────────┬────────────┘└────────────┬────────────┘└────────────┬────────────┘
             │                          │                          │
             └──────────────────────────┼──────────────────────────┘
                                        │
                                        ▼
                          ┌───────────────────────────┐
                          │  Cổng Kiểm Định QA 4 Tầng │
                          │   (scripts/qa_verifier)   │
                          └─────────────┬─────────────┘
                                        │
                                        ▼
                          ┌───────────────────────────┐
                          │     Ấn Phẩm Hoàn Tất      │
                          │  (PDF Vector 100% + MP4)  │
                          └───────────────────────────┘
```

---

## ⚡ 3. Cài Đặt Nhanh (Quick Start)

### 3.1. Yêu Cầu Môi Trường
- Python 3.10 trở lên.
- Đã cài đặt `ffmpeg` (để xuất video và chuẩn hóa audio).

### 3.2. Cài Đặt Thư Viện
Giải nén tệp `pdf-translation-layout-v3.0.1.zip` (nhận qua email đăng ký), sau đó:
```bash
cd pdf-translation-layout
pip install -r requirements.txt
```
> Xem thêm `BAT_DAU_TAI_DAY.md` để cài đặt theo từng nền tảng trong 5 phút.

---

## 🛠️ 4. Bảng Tra Cứu Lệnh CLI Nhanh

Toàn bộ tính năng được gói gọn trong giao diện điều khiển `scripts/cli.py`:

```bash
# 1. Kiểm kê thông số kỹ thuật PDF nguồn (trang, fonts, ảnh, liên kết)
python scripts/cli.py inspect --source input/book.pdf --out-dir data/

# 2. Dịch đơn ngữ giữ nguyên 100% layout vector
python scripts/cli.py translate-mono --source input/book.pdf --trans data/translations.json --out output/book_VI.pdf

# 3. Xuất 2 layout song ngữ (Đối trang 1-1 và Xen đoạn)
python scripts/cli.py bilingual --source input/book.pdf --trans output/book_VI.pdf --mode all

# 4. Lồng tiếng và tổng hợp âm thanh giọng đọc AI
python scripts/cli.py voice synth --text "Xin chào độc giả" --lang vi --voice "Đức Trí" --out intro.wav

# 5. Nhân bản giọng nói từ tệp mẫu 3-8 giây
python scripts/cli.py voice clone --name "GiongCuaToi" --lang vi --ref sample.wav --ref-text "Câu thoại mẫu"

# 6. Xuất bản Video đọc sách Full HD 1080p chuẩn broadcast (25fps, 48kHz)
python scripts/cli.py video --source input/book.pdf --trans output/book_VI.pdf --manifest data/manifest.json --mode bilingual --out output/video.mp4

# 7. Chạy Cổng kiểm định chất lượng 4 tầng tự động
python scripts/cli.py qa --source input/book.pdf --target output/book_VI.pdf --report data/qa_report.json
```

---

## 🌐 5. Hướng Dẫn Sử Dụng Đa Nền Tảng

Hệ sinh thái hỗ trợ đầy đủ 3 nền tảng AI Agent hàng đầu:
- 📖 [Cẩm Nang Sử Dụng Cho **Antigravity IDE**](GUIDE_ANTIGRAVITY.md)
- 🤖 [Cẩm Nang Sử Dụng Cho **Claude Code CLI**](GUIDE_CLAUDE.md)
- 💬 [Cẩm Nang Tích Hợp **OpenAI ChatGPT & Custom GPTs**](GUIDE_CHATGPT.md)

---

## 📄 6. Giấy Phép & Đóng Góp

- Phát hành theo giấy phép mã nguồn mở [MIT License](LICENSE).
- Mọi đóng góp (Pull Request, Báo cáo lỗi, Đề xuất tính năng) đều được chào đón!
